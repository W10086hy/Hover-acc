"""Component VJP parity and closed-loop timing for onboard CUDA graphs."""
import argparse,time
from pathlib import Path
import torch
from P2.hover_bptt.actor import Actor
from P2.hover_bptt.optimizer import initialize
from P2.hover_bptt.io import read,write,load_checkpoint,digest
from P2.hover_bptt.training import trajectory
from P3.mismatch_dynamics import DynamicsResidual
from .height_speed import ROOT,protocol_for
from .frame_environment import build_training
from .frame_stream import FrameStream
from .frozen_graph import FrozenFunctionGraph,controller_function,history_function,install


def parity(function,inputs):
    values=tuple(v.detach().clone().requires_grad_(v.is_floating_point()) for v in inputs);kernel=FrozenFunctionGraph(function,values)
    expected=function(*values);actual=kernel(*values);indices=[j for j,v in enumerate(expected) if v.requires_grad]
    weights=[torch.randn_like(expected[j]) for j in indices];variables=[v for v in values if v.requires_grad]
    a=torch.autograd.grad([expected[j] for j in indices],variables,weights,allow_unused=True)
    b=torch.autograd.grad([actual[j] for j in indices],variables,weights,allow_unused=True)
    maximum=0.
    for e,c in zip(expected,actual):torch.testing.assert_close(c,e,atol=0,rtol=0)
    for source,left,right in zip(variables,a,b):
        left=torch.zeros_like(source) if left is None else left;right=torch.zeros_like(source) if right is None else right
        torch.testing.assert_close(right,left,atol=2e-5,rtol=2e-5);maximum=max(maximum,float((right-left).abs().max()))
    return dict(forward_bitwise_equal=True,vjp_max_abs=maximum,float_inputs=len(variables))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True);p.add_argument('--seconds',type=float,default=3.);a=p.parse_args();out=Path(a.output).resolve()
    if out.exists() or not out.is_relative_to(ROOT/'track'):raise ValueError('Use a new track validation output')
    torch.set_num_threads(2);suite=read(ROOT/'track/configs/height_speed_suite.json');protocol=protocol_for(suite,10.)
    protocol.update(duration_s=a.seconds,state_seed=suite['training_seed_pair'][0],wind_seed=suite['training_seed_pair'][1])
    saved,sha=load_checkpoint(ROOT/suite['baseline_actor']);learned,net_sha=load_checkpoint(ROOT/suite['baseline_residual']);torch.manual_seed(protocol['state_seed'])
    actor=Actor(saved['configuration']['model']).cuda();actor.load_state_dict(saved['actor']);actor.train();initialize(actor,saved)
    residual=DynamicsResidual(learned['model_configuration']).cuda();residual.load_state_dict(learned['residual']);residual.requires_grad_(False)
    env=build_training(protocol,saved,residual);env.install_cuda_graph();packet=env.packet
    env.controller.set_observation(env.obs['policy'],env.parameter_context);env.controller.compensation_ticks.fill_(300)
    names,fn=controller_function(env.controller,env.dt)
    inputs=tuple(getattr(env.controller,n) for n in names)+(packet.attitude,packet.gyro,packet.specific_force,packet.motor_speed,packet.baro_height,env.state.new_zeros(env.n,4))
    checks=dict(controller=parity(fn,inputs));env.controller.compensation_ticks.zero_()
    objects,names,fn=history_function(env.history)
    inputs=tuple(getattr(objects[i],n) for i,n in names)+(packet.attitude,packet.gyro,packet.specific_force,packet.motor_speed,packet.baro_height,env.controller.previous)
    checks['history']=parity(fn,inputs);checks['loads']=parity(env.model.loads,(env.state,env.wind()))
    start=time.perf_counter();graphs=install(env);torch.cuda.synchronize();setup=time.perf_counter()-start
    stream=FrameStream(env);stream.hidden=env.state.new_zeros(1,env.n,saved['configuration']['model']['gru_hidden']);torch.cuda.reset_peak_memory_stats();start=time.perf_counter()
    steps=round(a.seconds/env.dt);loss,diagnostics,score,_=trajectory(stream,actor,gradient=True,steps=steps,credit_steps=min(1000,steps),recompute_steps=100)
    torch.cuda.synchronize();duration=time.perf_counter()-start;norm=float(torch.nn.utils.clip_grad_norm_(actor.parameters(),float('inf'),error_if_nonfinite=True))
    if a.seconds==3:
        reference=read(ROOT/'track/results/frame_qualification_cuda/qualification.json')
        assert score==reference['baseline'],'Closed-loop CUDA graph forward differs from eager onboard execution'
        torch.testing.assert_close(torch.tensor(norm),torch.tensor(reference['gradient_norm']),atol=2e-4,rtol=2e-4)
    write(out,dict(passed=True,component_checks=checks,objective_s=a.seconds,credit_s=min(10.,a.seconds),recompute_s=1.,setup_s=setup,gradient_s=duration,
        actor_gradient_norm=norm,loss=loss,score=score,diagnostics=diagnostics,actor_checkpoint_sha256=sha,residual_checkpoint_sha256=net_sha,optimizer_updates=0,
        peak_cuda_memory_mib=torch.cuda.max_memory_allocated()/2**20,source_sha256={n:digest(ROOT/n) for n in ['track/frozen_graph.py','track/validate_frozen_graph.py']}))
    print(dict(passed=True,seconds=a.seconds,gradient_s=duration,setup_s=setup,gradient_norm=norm,checks=checks),flush=True)


if __name__=='__main__':main()
