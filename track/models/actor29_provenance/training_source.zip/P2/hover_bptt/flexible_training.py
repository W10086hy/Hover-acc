"""Actual-trajectory objectives and bounded paired updates for dynamic cable."""
import copy
import math
import time
from pathlib import Path
import torch
from .actor import actor_mean
from .stream import RateFlightStream,heading_error_cost,settings,convergence_cost
from .state import snapshot,restore_stream
from .training import trajectory
from .io import digest,read

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent


class FlexibleRopeStream(RateFlightStream):
    """Keep the measured flight losses; no counterfactual with stale rope nodes."""
    def __init__(self,env):
        super().__init__(env);self.heading=settings(env.cfg)

    def step(self,actor):
        env=self.env;included=self.alive.clone();previous=env.state;motor=env.controller.previous
        cost=super().step(actor);extra=torch.zeros_like(cost).expand(env.n)
        if self.heading:extra=extra+heading_error_cost(env.state,self.heading)
        c=env.cfg['training'].get('hover_convergence_BPTT',{})
        if c.get('active',False):extra=extra+convergence_cost(previous,env.state,motor,env.controller.previous,
            env.model.target,self.steps*env.dt,env.dt,c)
        return cost+torch.where(included&self.alive,extra,torch.zeros_like(extra)).mean()


def validate_protocol(p):
    if (p['credit_s'],p['recompute_s'])!=(10,1):raise ValueError('Keep10s credit/1s recomputation')
    if p['objective_s']!=120:
        if not (p['objective_s']==30 and p.get('development_pilot') is True and p.get('formal_objective_s')==120):
            raise ValueError('Only explicitly requested30s development pilot may shorten the objective')
    reserved={v for pair in read(ROOT/'acceptance.json')['final_seed_pairs'] for v in pair.values()}
    reserved|={v for pair in read(ROOT/'p2_protocol.json')['reserved_generalization_final_seed_pairs'] for v in pair}
    train={p['training_seed'],p['training_seed']+1};dev={p['development_seed'],p['development_seed']+1}
    if train&dev or (train|dev)&reserved:raise ValueError('Keep train/development/final seeds separate')
    if set(p['training_directions_deg'])&set(p['development_directions_deg']):raise ValueError('Hold out development directions')
    if p['final_acceptance'] or p['maximum_paired_trials'] not in (1,2,3):raise ValueError('Bounded development continuation only')
    height_tolerance=p.get('height_absolute_tolerance_m',.01)
    if not math.isfinite(height_tolerance) or not 0<=height_tolerance<=.03:
        raise ValueError('Height regression allowance must stay within0..3cm')
    if 'optimizer_learning_rates' in p:
        values=p['optimizer_learning_rates']
        if len(values)!=3 or any(not math.isfinite(v) or v<=0 for v in values):raise ValueError('Three positive finite learning rates required')
    if 'training_winds' in p:
        if not p['training_winds'] or any(not math.isfinite(float(v)) or not 0<=v<=5 or profile not in ['steady','combined'] for v,profile in p['training_winds']):
            raise ValueError('Explicit training winds within0..5mps required')


def configure_learning_rates(optimizer,values=None):
    before=[g['lr'] for g in optimizer.param_groups]
    if values is not None:
        if len(values)!=len(before) or any(not math.isfinite(v) or v<=0 for v in values):raise ValueError('Positive finite group learning rates required')
        for group,value in zip(optimizer.param_groups,values):group['lr']=float(value)
    return before,[g['lr'] for g in optimizer.param_groups]


def source_manifest(protocol_path=None):
    files=sorted((ROOT/'hover_bptt').rglob('*.py'))+sorted((ROOT/'hover_bptt/configs').glob('*.json'))
    files+=[ROOT/name for name in ('configuration.json','flexible_rope_protocol.json',
        'qualify_flexible_rope.py','train_flexible_rope.py','evaluate_flexible_rope.py','animate.py')]
    if protocol_path is not None:
        selected=Path(protocol_path).resolve()
        if not selected.is_relative_to(REPO.resolve()):raise ValueError('Protocol must stay inside this project')
        files.append(selected)
    return {p.relative_to(REPO).as_posix():digest(p) for p in files}


def progress(stream):
    native=stream.step;last=[time.perf_counter()]
    def step(actor):
        value=native(actor)
        if time.perf_counter()-last[0]>=25:
            last[0]=time.perf_counter()
            print(dict(stage='flexible_BPTT_recompute' if torch.is_grad_enabled() else 'flexible_forward',
                simulation_s=round(stream.steps*stream.env.dt,2),safe=int(stream.alive.sum()),count=stream.env.n),flush=True)
        return value
    stream.step=step


def paired_decision(before,after,duration_s,height_absolute_tolerance_m=.01):
    reasons=[]
    try:
        if not math.isfinite(height_absolute_tolerance_m) or not 0<=height_absolute_tolerance_m<=.03:
            raise ValueError('Invalid height regression allowance')
        n=len(before['completed'])
        if not n or before['duration_s']!=duration_s or after['duration_s']!=duration_s:raise ValueError('Horizon differs')
        for key in ['vehicle_identity','wind_seed','attachment','wind_speed','direction_rad','wind_profile']:
            if before[key]!=after[key]:raise ValueError('Course differs')
        for score in [before,after]:
            if not math.isfinite(score['cost']) or len(score['completed'])!=n:raise ValueError('Invalid score')
            for key in ['position_rmse_m','height_rmse_m','horizontal_rmse_m','maximum_true_yaw_error_deg']:
                if len(score[key])!=n or any(not math.isfinite(v) or v<0 for v in score[key]):raise ValueError('Invalid metric')
        if any(b and not a for b,a in zip(before['completed'],after['completed'])):reasons.append('new_failure')
        if after['cost']>=before['cost']:reasons.append('full_cost_not_lower')
        rms=lambda s:math.sqrt(sum(v*v for v in s['position_rmse_m'])/n)
        if rms(after)>rms(before)*1.05+.01:reasons.append('aggregate_position_regression')
        if any(a>b*1.1+height_absolute_tolerance_m for a,b,ok in zip(after['height_rmse_m'],before['height_rmse_m'],before['completed']) if ok):
            reasons.append('safe_height_regression')
        if any(a>max(5.,b+.5) for a,b,ok in zip(after['maximum_true_yaw_error_deg'],before['maximum_true_yaw_error_deg'],before['completed']) if ok):
            reasons.append('safe_heading_regression')
    except (KeyError,TypeError,ValueError):reasons.append('invalid_or_unpaired_score')
    return dict(accepted=not reasons,reasons=reasons)


def paired_update(stream,actor,optimizer,protocol):
    validate_protocol(protocol)
    duration=protocol['objective_s'];steps=round(duration/stream.env.dt)
    credit=round(protocol['credit_s']/stream.env.dt);recompute=round(protocol['recompute_s']/stream.env.dt)
    if stream.env.episode_steps!=steps:raise ValueError('Environment must match the complete objective')
    before=snapshot(stream.env,stream,actor,optimizer,updates=0,episode=0,window=0)
    actor.zero_grad(set_to_none=True)
    loss,diag,baseline,base_commands=trajectory(stream,actor,gradient=True,steps=steps,credit_steps=credit,recompute_steps=recompute)
    norm=float(torch.nn.utils.clip_grad_norm_(actor.parameters(),1.,error_if_nonfinite=True))
    optimizer.step();proposal={k:v.detach().clone() for k,v in actor.state_dict().items()};adam=copy.deepcopy(optimizer.state_dict())
    trials=[];accepted=False
    for i in range(protocol['maximum_paired_trials']):
        restore_stream(stream.env,stream,actor,optimizer,before);fraction=.5**i
        actor.load_state_dict({k:v+fraction*(proposal[k]-v) for k,v in before['actor'].items()})
        _,_,candidate,commands=trajectory(stream,actor,steps=steps)
        decision=paired_decision(baseline,candidate,duration,protocol.get('height_absolute_tolerance_m',.01))
        reasons=decision['reasons'];accepted=decision['accepted']
        trials.append(dict(fraction=fraction,accepted=accepted,reasons=reasons,score=candidate,
                           different_trajectory_max_command_change=(commands-base_commands).abs().amax((0,1)).tolist()))
        print(dict(stage='flexible_full_horizon_candidate',duration_s=duration,fraction=fraction,accepted=accepted,cost=candidate['cost'],
                   safe=sum(candidate['completed']),reasons=reasons),flush=True)
        if accepted:optimizer.load_state_dict(adam);break
    if not accepted:restore_stream(stream.env,stream,actor,optimizer,before)
    if not torch.equal(actor.fast_head.weight[:,:8].detach(),before['actor']['fast_head.weight'][:,:8]):raise RuntimeError('Frozen fast feedback changed')
    return dict(**diag,accepted=accepted,gradient_objective_loss=loss,gradient_norm=norm,
                baseline=baseline,accepted_score=trials[-1]['score'] if accepted else baseline,trials=trials,
                continuous_objective_s=duration,gradient_credit_s=protocol['credit_s'],recompute_s=protocol['recompute_s'],
                height_absolute_tolerance_m=protocol.get('height_absolute_tolerance_m',.01),
                development_pilot=duration<120,formal_objective_s=120,full_untruncated120s_gradient=False)
