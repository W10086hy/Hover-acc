"""Current26-policy domains, immutable sources, and flexible-plant construction."""
import copy,zipfile
from pathlib import Path
import torch
from P2.hover_bptt.environment import plant_config
from P2.hover_bptt.flexible_rope import FlexibleRopeModel
from P2.hover_bptt.flexible_environment import FlexibleRopeEvaluationEnvironment
from P2.hover_bptt.dynamics.torch_model import CapturedControl
from P2.hover_bptt.generalization import cases_at
from P2.hover_bptt.vehicle_spec import VehicleSpec
from P2.hover_bptt.io import read,write,digest,load_checkpoint
from .mismatch_data import nominal_geometry,validate_protocol,reserved_seeds

ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent


def load_protocol(path):
    protocol=read(path)
    validate_protocol(protocol,reserved_seeds(read(REPO/'P2/acceptance.json'),read(REPO/'P2/p2_protocol.json')))
    if protocol['plant_kind']!='dynamic_flexible_rope' or protocol['policy_updates']!=0:raise ValueError('Frozen-policy flexible P3 only')
    saved,sha=load_checkpoint(ROOT/protocol['controller_checkpoint'])
    if sha!=protocol['controller_checkpoint_sha256'] or saved['cumulative_physical_updates']!=26:
        raise ValueError('Use the fixed current26 Actor/Adam, not an old P3 policy')
    return protocol,saved,sha


def build_domain(group,device,rope):
    base=plant_config();reference=VehicleSpec.from_config(base)
    actual=reference.scaled(**group.get('actual_scales',{}));nominal=reference.scaled(**group.get('nominal_scales',{}))
    cases=cases_at(group['directions_deg'])
    for case in cases:case['actual_body_drag_scale']=group.get('actual_drag_scale',1.)
    arms,lengths=nominal_geometry(cases,group.get('nominal_arm_cm',5),device)
    pc=nominal.apply(base);pc['aero']['body_drag_n_per_mps2']=[v*group.get('nominal_drag_scale',1.) for v in base['aero']['body_drag_n_per_mps2']]
    model=FlexibleRopeModel(pc,device=device,arms=arms,lengths=lengths,rope=rope)
    return base,actual,nominal,cases,pc,model


def capture_control(env):
    if str(env.device).startswith('cuda') and isinstance(env.model,FlexibleRopeModel):
        commands=torch.cat((env.controller.previous,torch.zeros_like(env.controller.previous[:,:2])),-1)
        winds=env.wind()[:,None].expand(-1,env.model.substeps,-1).contiguous()
        env.model.control=CapturedControl(env.model,env.state,commands,winds)
    return env


def sources(protocol_path):
    files=sorted((REPO/'P2/hover_bptt').rglob('*.py'))+sorted((REPO/'P2/hover_bptt/configs').glob('*.json'))
    files += [REPO/name for name in ['P2/configuration.json','P2/acceptance.json','P2/p2_protocol.json',
        'P3/flexible_domains.py','P3/collect_flexible.py','P3/flexible_compensation.py','P3/evaluate_flexible.py',
        'P3/train_mismatch.py','P3/mismatch_data.py','P3/mismatch_dynamics.py','P3/collect_mismatch.py','P3/compensation.py',
        'P3/flexible_labels.py','P3/relabel_flexible.py',
        'mujoco_sim/flexible.py','mujoco_sim/physics.py']]
    selected=Path(protocol_path).resolve()
    if not selected.is_relative_to(REPO):raise ValueError('Protocol must remain in the project')
    files.append(selected)
    return {p.relative_to(REPO).as_posix():digest(p) for p in files}


def freeze(out,manifest):
    with zipfile.ZipFile(Path(out)/'frozen_source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for name in manifest:z.write(REPO/name,arcname=name)


def protected(protocol):
    names=[ROOT/protocol['controller_checkpoint'],REPO/'P2/results/training/conditioned/latest.pt',ROOT/'results/residual/best.pt']
    return {p.resolve().relative_to(REPO).as_posix():digest(p) for p in names}


def check_unchanged(manifest,files):
    if not all(digest(REPO/name)==sha for name,sha in {**manifest,**files}.items()):raise RuntimeError('Source or protected checkpoint changed')


def set_status(stage,**fields):
    write(ROOT/'flexible_status.json',dict(stage=stage,policy_updates=0,**fields))
    current=read(ROOT/'status.json');current.update(stage=stage,training_running=fields.get('training_running',False),validation_running=fields.get('validation_running',False),flexible_run_output=fields.get('output'))
    write(ROOT/'status.json',current)
    state=read(REPO/'project_state.json');state.update(p3_flexible_stage=stage,
        training_running=fields.get('training_running',False),validation_running=fields.get('validation_running',False))
    write(REPO/'project_state.json',state)
