"""Verify flexible P3 evidence without retraining or altering archived results."""
import argparse,hashlib,zipfile
from pathlib import Path
import numpy as np
import torch
from PIL import Image
from P2.hover_bptt.io import read,write,digest,load_checkpoint
from .flexible_domains import ROOT,load_protocol,protected,check_unchanged
from .mismatch_data import load_record


def archive_matches(folder,metadata):
    manifest=metadata['source_sha256']
    with zipfile.ZipFile(folder/'frozen_source.zip') as z:
        return all(hashlib.sha256(z.read(name)).hexdigest()==sha for name,sha in manifest.items())


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',default=str(ROOT/'results/flexible26_structural'))
    p.add_argument('--protocol',default=str(ROOT/'flexible26_structural_protocol.json'));a=p.parse_args();base=Path(a.root)
    if (base/'completion_audit.json').exists():raise FileExistsError('Preserve prior completion audit')
    protocol,actor,sha=load_protocol(a.protocol);net,net_sha=load_checkpoint(base/'residual/best.pt')
    data=read(base/'data/summary.json');fit=read(base/'residual/training_summary.json');test=read(base/'prediction/summary.json')
    assert data['completed'] and fit['completed'] and test['completed']
    assert sha==net['controller_checkpoint_sha256']==test['controller_checkpoint_sha256']
    assert net_sha==test['residual_checkpoint_sha256']==fit['selected_checkpoint_sha256']
    assert not fit['test_used_for_selection'] and not net['test_used_for_selection']
    prefix='rnn.rnn.'
    assert all(torch.equal(value,net['residual']['history.'+key[len(prefix):]]) for key,value in actor['actor'].items() if key.startswith(prefix))
    checks={};archives={}
    for relative in ['data','residual','comparison_torch','comparison_mujoco']:
        folder=base/relative;metadata=read(folder/'protocol.json');archives[relative]=archive_matches(folder,metadata)
        assert archives[relative]
    for item in data['groups']:
        record_path=base/'data'/item['split']/(item['group']['name']+'.pt')
        assert digest(record_path)==item['data_sha256']
    matched=load_record(base/'data/train/matched.pt')
    assert not bool((matched['targets']!=0).any())
    if 'source_record' in matched:
        original=(base/'data/train'/matched['source_record']).resolve()
        raw_protocol=read(original.parent.parent/'protocol.json')
        check_unchanged({},raw_protocol['protected_files'])
    init=[];winds=[];results=[];all_states=[];replays=[]
    for backend in ['torch','mujoco']:
        folder=base/('comparison_'+backend);summary=read(folder/'summary.json');assert summary['completed']
        assert summary['checkpoint_sha256']==sha and summary['residual_checkpoint_sha256']==net_sha
        assert summary['initial_states_and_full_wind_equal'] and summary['actual_parameters_identical']
        assert summary['policy_updates']==0 and not summary['optimizer_created'] and not summary['residual_force_added_to_actual_plant']
        initial=[];wind=[];backend_states=[]
        for name in ['without_compensation','with_compensation']:
            r=read(folder/name/'result.json');assert r['duration_s']==30 and r['policy_weights_unchanged']
            with np.load(folder/name/'trajectory.npz') as data_trace:
                assert data_trace['times'][0]==0 and data_trace['times'][-1]==30
                assert data_trace['state'].shape==(301,16,86);initial.append(data_trace['state'][0].copy());backend_states.append(data_trace['state'].copy())
            wind.append(torch.load(folder/name/'wind_trace.pt',map_location='cpu',weights_only=False)['wind_w_mps'])
            assert torch.load(folder/name/'heading_witness.pt',map_location='cpu',weights_only=False).shape==(3001,16)
        assert np.array_equal(initial[0],initial[1]) and torch.equal(wind[0],wind[1])
        init.append(initial[0]);winds.append(wind[0]);results.append(summary);all_states.append(backend_states)
        for stem in ['weak_without','weak_with','strong_without','strong_with']:
            path=folder/'visuals'/stem;metadata=read(path.with_suffix('.json'))
            policy='without_compensation' if stem.endswith('without') else 'with_compensation'
            assert metadata['animation_start_s']==0 and metadata['animation_end_s']==30 and metadata['metric_horizon_s']==30
            assert metadata['altitude_axis_min_m']==0 and metadata['horizontal_distance_axis_min_m']==0
            assert metadata['checkpoint_sha256']==sha and metadata['source_result_sha256']==digest(folder/policy/'result.json')
            assert metadata['source_trajectory_sha256']==digest(folder/policy/'trajectory.npz')
            assert metadata['gif_sha256']==digest(path.with_suffix('.gif')) and metadata['png_sha256']==digest(path.with_suffix('.png'))
            with Image.open(path.with_suffix('.gif')) as gif:assert gif.n_frames==metadata['frames']==51
            replays.append(dict(file=str(path.with_suffix('.gif')),residual_checkpoint_sha256=net_sha,
                source_comparison_protocol_sha256=digest(folder/'protocol.json'),verified=True))
        checks[backend]=dict(duration_s=30,count_per_policy=16,policy_updates=0,
            safe_completed=[r['safe_completed'] for r in summary['policies']],
            rmse_3d_h_xy_m=[r['rmse_3d_h_xy_m'] for r in summary['policies']],
            relative_3d_improvement=summary['relative_3d_improvement'],initial_states_and_wind_equal=True,
            source_and_protected_files_unchanged=summary['source_and_protected_files_unchanged'])
    check_unchanged({},protected(protocol));assert digest(base/'residual/best.pt')==net_sha
    archive_files=['P3/score_flexible.py','P3/report_flexible.py','P3/report_flexible_model.py','P3/audit_flexible.py','P2/visualize_full_flight.py']
    with zipfile.ZipFile(base/'report_sources.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for name in archive_files:z.write(ROOT.parent/name,arcname=name)
    write(base/'completion_audit.json',dict(completed=True,controller_checkpoint_sha256=sha,residual_checkpoint_sha256=net_sha,
        policy_and_old_checkpoints_unchanged=True,frozen_history_equals_current26_actor=True,matched_wrench_labels_exactly_zero=True,
        collection_and_fit_archived_sources_valid=archives,data_sha256_verified=True,
        paired_checks=checks,cross_backend_initial_states_equal=np.array_equal(init[0],init[1]),cross_backend_full_wind_equal=torch.equal(winds[0],winds[1]),
        maximum_saved_cross_backend_position_difference_m={name:float(np.linalg.norm(all_states[0][j][:,:,:3]-all_states[1][j][:,:,:3],axis=-1).max()) for j,name in enumerate(['without_compensation','with_compensation'])},
        full_horizon_replays=replays,
        selected_step=fit['selected_step'],training_wall_s=fit['wall_s'],test_used_for_selection=False,
        report_sources_sha256={name:digest(ROOT.parent/name) for name in archive_files},formal_final_acceptance=False))
    print(dict(completed=True,paired_checks=checks),flush=True)


if __name__=='__main__':main()
