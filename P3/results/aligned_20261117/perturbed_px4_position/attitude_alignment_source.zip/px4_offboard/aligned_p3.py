"""Nine residuals on a fixed policy grid, with measured interval RPM moments."""
from dataclasses import replace
import numpy as np
from .control import Observer
from .unified_p3 import UnifiedCalibration, nominal_alpha
from .policy_timing import POLICY_DT, FORCE_ALPHA, measured_motor_moments

PROCESSING = dict(policy_dt_s=POLICY_DT, force_filter_alpha=FORCE_ALPHA,
                  motor_moments='measured_rpm_linear')


def support_confidence(features,parameters):
    gate=parameters.get('feature_support_gate')
    if gate is None:return np.ones(np.asarray(features).shape[:-1])
    z=np.abs((features-np.asarray(parameters['feature_mean']))/np.asarray(parameters['feature_scale']))
    return np.clip((gate['zero_above']-z.max(axis=-1))/(gate['zero_above']-gate['full_below']),0,1)


def angular_prediction(features,weights,limits,parameters):
    confidence=support_confidence(features,parameters)
    if parameters.get('feature_support_fallback')=='training_mean':
        mean=np.asarray(parameters['feature_mean'])
        supported=mean+confidence[...,None]*(features-mean)
        return np.clip(supported@np.asarray(weights).T,-limits,limits)
    return np.clip(features@np.asarray(weights).T,-limits,limits)*confidence[...,None]


def aligned_features(previous_gyro, force, previous_rpm, rpm):
    w = np.asarray(previous_gyro)
    a, b = np.asarray(previous_rpm), np.asarray(rpm)
    square, mean = measured_motor_moments(a, b)
    spin = mean @ np.array([1., -1., -1., 1.])
    quadratic = np.stack([w[..., i]*w[..., j] for i,j in
        ((0,0),(1,1),(2,2),(0,1),(0,2),(1,2))], axis=-1)
    features = np.concatenate((np.ones(w.shape[:-1]+(1,)),w/.5,quadratic/.25,
        np.asarray(force)/10.,square/360000.,a*a/360000.,b*b/360000.,spin[...,None]*w/300.),axis=-1)
    return features, square, mean


class AlignedCalibration(UnifiedCalibration):
    def __init__(self, parameters):
        if parameters.get('schema')!='P3_aligned_residual_v2' or parameters.get('processing')!=PROCESSING:
            raise ValueError('Aligned P3 needs its exact 100Hz/filter/measured-RPM contract')
        super().__init__({**parameters,'schema':'P3_unified_residual_v1'})
        self.parameters = parameters
        if 'feature_mean' in parameters:
            mean,scale=np.asarray(parameters['feature_mean']),np.asarray(parameters['feature_scale'])
            if mean.shape!=(28,) or scale.shape!=(28,) or not np.isfinite(mean).all() or not np.isfinite(scale).all() or (scale<=0).any():
                raise ValueError('Finite training-only feature normalization required')
        if 'feature_support_gate' in parameters:
            gate=parameters['feature_support_gate']
            if 'feature_mean' not in parameters or gate!={'full_below':4.,'zero_above':8.}:
                raise ValueError('Supported Position feature gate required')
        if parameters.get('feature_support_fallback','zero') not in ('zero','training_mean'):
            raise ValueError('Unknown P3 support fallback')
        if parameters.get('feature_support_fallback')=='training_mean' and 'feature_mean' not in parameters:
            raise ValueError('Training mean required for supported residual fallback')
        self.attitude_right=np.asarray(parameters.get('attitude_right_quaternion',[1.,0,0,0]),float)
        if (self.attitude_right.shape!=(4,) or not np.isfinite(self.attitude_right).all()
            or abs(np.linalg.norm(self.attitude_right)-1)>1e-8 or abs(self.attitude_right[3])>1e-10
            or self.attitude_right[0]<np.cos(np.deg2rad(3)/2)):
            raise ValueError('Validated small right-tilt attitude correction required')

    def correct_packet(self,packet):
        from .p3_observer import multiply
        corrected=super().correct_packet(packet)
        q=multiply(corrected.attitude,self.attitude_right)
        return replace(corrected,attitude=q/np.linalg.norm(q))


class AlignedObserver(Observer):
    def __init__(self,cfg,calibration,dt=POLICY_DT):
        if not np.isclose(dt,POLICY_DT,rtol=0,atol=1e-12):raise ValueError('Frozen P2 requires 10ms grid')
        calibration.validate_reference(cfg['nominal'])
        self.calibration=calibration
        super().__init__(cfg,dt)

    def reset(self):
        super().reset()
        self.sample_dt_s=self.dt
        self.previous_force=np.zeros(3)
        self.unified_compensation=np.zeros(9)
        self.equivalent_self_torque=np.zeros(3)
        self.innovation_before=np.zeros(3)
        self.innovation_after=np.zeros(3)
        self.last_standardized_packet=None
        self.feature_ood_fraction=0.
        self.support_confidence=1.
        self.innovation_clipped_before=np.zeros(3,dtype=bool)
        self.innovation_clipped_after=np.zeros(3,dtype=bool)

    def update(self,packet,applied):
        if not np.isclose(self.sample_dt_s,self.dt,rtol=0,atol=1e-9):
            raise ValueError('Resample source clock before the frozen Actor')
        valid=self.valid
        force=.5*(self.previous_force+packet.specific_force) if valid else packet.specific_force
        features,square,mean=aligned_features(self.rate,force,self.rpm,packet.motor_speed)
        self.support_confidence=float(support_confidence(features,self.calibration.parameters))
        own=angular_prediction(features,self.calibration.angular_weights,
            self.calibration.angular_limit,self.calibration.parameters)
        predicted=self.rate+self.dt*nominal_alpha(self.rate,square,mean,self.pc)
        self.innovation_before=packet.gyro-predicted if valid else np.zeros(3)
        self.innovation_after=self.innovation_before-self.dt*own if valid else np.zeros(3)
        result=super().update(replace(packet,interval_motor_moments=(square,mean,self.dt)),applied)
        result[23:26]=np.clip(self.innovation_after/.1,-5,5)
        self.innovation_clipped_before=np.abs(self.innovation_before)>.5
        self.innovation_clipped_after=np.abs(self.innovation_after)>.5
        self.equivalent_self_torque=self.J*own
        self.unified_compensation=np.r_[self.calibration.last_sensor_correction,own]
        self.previous_force=packet.specific_force.copy()
        self.last_standardized_packet=packet
        p=self.calibration.parameters
        if 'feature_mean' in p:
            z=(features-np.asarray(p['feature_mean']))/np.asarray(p['feature_scale'])
            self.feature_ood_fraction=float(np.mean(np.abs(z)>8))
        return result
