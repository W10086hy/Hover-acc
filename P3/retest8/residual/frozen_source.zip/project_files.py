"""Resolve byte-preserved artifacts relocated by the documented cleanup."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def resolve_artifact(name):
    path=Path(name)
    if path.is_absolute():
        resolved=path.resolve()
        if not resolved.is_relative_to(ROOT):raise ValueError('Artifact outside project')
        relative=resolved.relative_to(ROOT).as_posix()
    else:relative=path.as_posix().replace('\\','/')
    candidate=ROOT/relative
    if candidate.is_file():return candidate
    mapping=json.loads((ROOT/'cleanup/path_map.json').read_text(encoding='utf-8'))
    if relative not in mapping:raise FileNotFoundError('Artifact not retained: '+relative)
    relocated=(ROOT/mapping[relative]).resolve()
    if not relocated.is_relative_to(ROOT) or not relocated.is_file():raise FileNotFoundError(relative)
    return relocated
