"""MAVLink body-rate/thrust endpoint, also usable with an external sensor packet.

Only ATTITUDE_QUATERNION, HIGHRES_IMU, pressure and measured ESC speed enter
the policy. Navigation messages are deliberately ignored. All output uses
SET_ATTITUDE_TARGET with ATTITUDE_IGNORE=128, body rates rad/s, thrust[0,1].
"""
import time,collections
import numpy as np
from .control import Controller,Sensors

def pressure_to_height(pressure_hpa):
    return 44330.*(1.-(pressure_hpa/1013.25)**(1./5.255))

def relative_attitude(q,heading):
    c,s=np.cos(-heading/2),np.sin(-heading/2);w,x,y,z=q
    result=np.array([c*w-s*z,c*x-s*y,c*y+s*x,c*z+s*w],np.float32)
    return result if result[0]>=0 else -result

class Offboard:
    def __init__(self,link,cfg,weights,residual=True):
        self.link=link;self.controller=Controller(cfg,weights,residual=residual)
        self.messages={};self.received={};self.events=[];self.last_heartbeat=None;self.acks=[]
        self.heading=None;self.filtered_force=None;self.commands=0;self.latest=None
        self.rpm_history=collections.deque(maxlen=160);self.previous_gyro_time=None
    def record_motor_sample(self,rpm,clock):
        values=np.asarray(rpm,float)
        if values.shape!=(4,) or not np.isfinite(values).all():raise ValueError('Four measured motor speeds required')
        self.rpm_history.append((float(clock),values.copy()))
    def motor_moments(self,end):
        if self.previous_gyro_time is None:return None
        start=self.previous_gyro_time
        if end<=start:return None
        samples=list(self.rpm_history);times=np.array([v[0] for v in samples]);rpm=np.array([v[1] for v in samples])
        if len(times)<2 or times[0]>start or times[-1]<end:raise RuntimeError('RPM history does not cover gyro interval')
        grid=np.r_[start,times[(times>start)&(times<end)],end]
        speed=np.stack([np.interp(grid,times,rpm[:,i]) for i in range(4)],axis=-1)
        elapsed=end-start
        return np.trapezoid(speed**2,grid,axis=0)/elapsed,np.trapezoid(speed,grid,axis=0)/elapsed,elapsed
    def ingest(self,msg,clock):
        kind=msg.get_type()
        if kind=='HEARTBEAT' and msg.get_srcSystem()==1:
            self.last_heartbeat=msg
        if kind in ['ATTITUDE_QUATERNION','HIGHRES_IMU','SCALED_PRESSURE']:
            self.messages[kind]=msg;self.received[kind]=clock
        if kind=='COMMAND_ACK':self.acks.append(dict(command=msg.command,result=msg.result,time_s=clock))
        if kind=='STATUSTEXT':self.events.append(dict(time_s=clock,severity=msg.severity,text=msg.text))
    def pump(self,clock):
        while True:
            msg=self.link.recv_match(blocking=False)
            if msg is None:break
            self.ingest(msg,clock)
    def heartbeat(self):
        from pymavlink import mavutil
        self.link.mav.heartbeat_send(mavutil.mavlink.MAV_TYPE_ONBOARD_CONTROLLER,mavutil.mavlink.MAV_AUTOPILOT_INVALID,0,0,mavutil.mavlink.MAV_STATE_ACTIVE)
    def command(self,command,*args):
        params=[*args]+[0.]*(7-len(args));self.link.mav.command_long_send(1,1,command,0,*params)
    def setpoint(self,rates,thrust,clock):
        self.link.mav.set_attitude_target_send(int(clock*1000)&0xffffffff,1,1,128,[1,0,0,0],*map(float,rates),float(thrust))
        self.commands+=1
    def mode_arm(self):
        from pymavlink import mavutil
        self.command(mavutil.mavlink.MAV_CMD_DO_SET_MODE,1.,6.,0.)
        self.command(mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM,1.,0.)
    def is_offboard_armed(self):
        h=self.last_heartbeat
        return h is not None and bool(h.base_mode&128) and ((h.custom_mode>>16)&255)==6
    def update(self,rpm,applied,clock):
        if not all(k in self.messages for k in ['ATTITUDE_QUATERNION','HIGHRES_IMU','SCALED_PRESSURE']):return None
        if any(clock-self.received[k]>.25 for k in ['ATTITUDE_QUATERNION','HIGHRES_IMU','SCALED_PRESSURE']):
            raise RuntimeError('Stale PX4 onboard telemetry: refuse frozen sensor reuse')
        a=self.messages['ATTITUDE_QUATERNION'];imu=self.messages['HIGHRES_IMU'];baro=self.messages['SCALED_PRESSURE']
        q=np.array([a.q1,a.q2,a.q3,a.q4]);q/=np.linalg.norm(q)
        if self.heading is None:
            from .network import rotation
            r=rotation(q);self.heading=np.arctan2(r[1,0],r[0,0])
        force=np.array([imu.xacc,imu.yacc,imu.zacc])
        self.filtered_force=force if self.filtered_force is None else self.filtered_force+.5*(force-self.filtered_force)
        gyro_time=imu.time_usec/1e6
        if self.previous_gyro_time is not None and gyro_time<=self.previous_gyro_time:
            raise RuntimeError('PX4 gyro timestamp did not advance at policy tick')
        moments=self.motor_moments(gyro_time)
        packet=Sensors(relative_attitude(q,self.heading),np.array([imu.xgyro,imu.ygyro,imu.zgyro]),self.filtered_force,
            np.array(rpm),float(pressure_to_height(baro.press_abs)),moments)
        self.previous_gyro_time=gyro_time
        rates,thrust,info=self.controller(packet,np.array(applied))
        self.setpoint(rates,thrust,clock);self.latest=(packet,rates,thrust,info)
        return self.latest
