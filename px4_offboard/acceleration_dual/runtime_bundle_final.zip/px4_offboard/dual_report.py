"""Rebuild the retained dual-interface development report from raw evidence."""
from pathlib import Path
import json
from .dual_audit import audit,read,write,digest


def main():
    project=Path(__file__).resolve().parents[1];base=project/'px4_offboard/acceleration_dual'
    rows=[]
    for batch in ('full_01','full_02_mavros'):
        for wind in (1,5):
            for kind in ('acceleration','rate_thrust'):
                root=base/'results'/batch/f'{kind}_wind{wind}';a=audit(root)
                log=(root/'flight/px4.log').read_text(errors='replace')
                rows.append(dict(batch=batch,path=root.relative_to(base).as_posix(),audit=a,
                    firmware_log_counts=dict(magnetometer_stale=log.count('MAG #0 failed:  STALE'),
                        high_accelerometer_bias=log.count('High Accelerometer Bias'))))
    legacy=('px4_offboard/offboard.py','px4_offboard/control.py','px4_offboard/stock_transfer/stock_check_hold.py','px4_offboard/launch.sh')
    summary=dict(date='2026-11-16',controller_sha256=read(base/'assets/config.json')['controller_sha256'],
        P3_enabled=False,formal_final_acceptance=False,accepted_for_flight=False,policy_updates=0,
        duration_s=120,seeds=[2026114501,2026114503],attachment_cm=5,cases=rows,
        latest_batch='full_02_mavros',legacy_source_sha256={n:digest(project/n) for n in legacy},
        environment=read(base/'environment.json'),regression=dict(total=248,passed=247,skipped=1),
        scoring_note='Full planned 120 s; actual failing state then remaining h4/xy6m. Recorded fixture heartbeat barometric reference; original MAVROS node target was not logged separately.',
        source_note='Per-case frozen_source.zip is flight identity. Later maintenance adds policy target logging, CLI default mavros and audit/replay/report checks; no network updates.',
        limitations=['P3 OFF; full native P3 torque compensation preserved separately',
            'PX4 still receives simulated GPS; Actor does not receive horizontal position/velocity',
            'Single nominal body, 5cm attachment, one seed per wind; no independent acceptance',
            'Asynchronous separate runs do not have bit-identical initial states',
            'Firmware logs contain magnetometer stale and accelerometer-bias warnings; cause of oscillation not isolated'])
    write(base/'summary.json',summary)
    lines=['# PX4 双接口虚拟机开发验证（2026-11-16）','',
        '两条接口已通过实际 MAVROS／MAVLink 传输审计，但当前闭环性能未达标，尚不接受为可用飞行策略。完整 MAVROS 输入的最新四例中，两条强风例完成 120 s，两条弱风例高度保护终止；逐例 RMSE 和末段稳态均未通过。没有训练或更新网络。','',
        '同一冻结 Actor13＋Adam：`P2/results/acceleration_hover/altitude_robust/low_frequency_round/training/proposal01_trial01.pt`，SHA256 `'+summary['controller_sha256']+'`。机载输入 35 维、标称参数 14 维。P3 关闭；既有安装倾斜／质心／零偏完整模型和原生闭环结果保持不变。','',
        '## 最新：MAVROS 传感器输入与实际 MAVROS 输出','',
        '| 接口 | 风速 | 实录／计划时域 s | 三维／高度／水平 RMSE m | 安全完成 | 末段稳态 | 实际消息数 |',
        '| --- | --- | ---: | ---: | --- | --- | ---: |']
    for r in rows:
        if r['batch']!='full_02_mavros':continue
        a=r['audit'];kind='加速度＋PX4高度环' if a['interface']=='acceleration' else '角速度＋推力适配器'
        label='1 恒风' if a['wind_mps']==1 else '1→5，前5s渐升'
        rmse='/'.join(f'{n:.3f}' for n in a['rmse_3d_h_xy_m'])
        lines.append(f"| {kind} | {label} | {a['physical_post_duration_s']:.3f}/120 | {rmse} | {'是' if a['safe_completed'] else '否'} | {'是' if a['settled'] else '否'} | {a['actual_wire_commands']} |")
    lines+=['','弱风两例的失败后余下时域按水平 6 m／高度 4 m 计罚，以上是完整 120 s 评分，不是失败前短片的 RMSE。门限为弱风三维 0.5 m、强风 1.5 m。稳态为末 30 s 水平离散≤0.25 m、三维速度 RMS≤0.3 m/s、水平漂移≤0.01 m/s。原始值、实际时长与保护信息见各例 `audit.json`。','',
        '风沿工程 +y，弱风恒定 1 m/s；强风在接管后 5 s 按半余弦由 1 升至 5 m/s，此后恒定 5 m/s，瞬时峰值 5 m/s。传感器种子分别 2026114501、2026114503。仅 5 cm 挂点、标称 2.3 kg、2 ms 电机响应、EA49 N／4.90 m 有质量挠度绳。每接口独立启动 PX4，初态不是逐位一致。','',
        '加速度实际发送 84 号 `SET_POSITION_TARGET_LOCAL_NED`，mask=2363，NED z＋水平加速度＋航向有效；角速度实际发送 82 号 `SET_ATTITUDE_TARGET`，mask=128。代理保留实际字节、字段与时间，审计未发现掩码或坐标符号错误。两条路线都使用 0.065 s 加速度平滑，角速度适配器另有 0.065 s 输出平滑；它不等价于原生力矩控制。','',
        '高度按模式切入值锁存，不固定写成 5 m。原始完整 MAVROS 录像尚未单独记录节点内部的气压目标，因此本表统一采用夹具心跳锁存的气压参考（逐例见 audit），不能冒称节点目标的精确日志。实际加速度消息的本地 EKF z 锁存可在 wire_commands 中核对。后续维护版已补内部目标记录；本轮未据此重跑或更改冻结数值。','',
        '## 最新实际飞行回放','',
        '技术路线为 BPTT，12 倍速，XYZ 等比例；失败例只回放真实飞行片段，完整时域计罚只用于评分。','']
    for name,label in (('acceleration_wind1','加速度／弱风，保护终止'),('rate_thrust_wind1','角速度＋推力／弱风，保护终止'),('acceleration_wind5','加速度／强风，完整120s'),('rate_thrust_wind5','角速度＋推力／强风，完整120s')):
        lines += [f'**{label}**',f'![{label}](results/full_02_mavros/{name}/replay/flight.gif)','']
    lines+=['## 较早输入适配器对照','',
        '`full_01` 使用 MAVLink 机载遥测适配器和实际 MAVROS 输出；其额外实测电机区间矩与最新机载节点的标称区间预测不同，不能混作同一路径。四例均未达 RMSE 门限：','',
        '| 接口／风 m/s | 实录 s | 三维／高度／水平 RMSE m | 安全／稳态 |','| --- | ---: | ---: | --- |']
    for r in rows:
        if r['batch']!='full_01':continue
        a=r['audit'];lines.append(f"| {a['interface']}／{a['wind_mps']:g} | {a['physical_post_duration_s']:.3f} | {'/'.join(f'{n:.3f}' for n in a['rmse_3d_h_xy_m'])} | {a['safe_completed']}／{a['settled']} |")
    lines+=['','## 证据、来源和边界','',
        '每例保存 `flight/trace.npy`（250 Hz 真值，仅物理与评价）、PX4 ULog／日志、实际 `wire_commands.json`、预飞校准、`interface.json` 和飞行 `frozen_source.zip`。最新节点的 `policy_runtime.json` 确认 2000 个有效校准样本及非零真实推理步数。`summary.json` 汇总八例，`environment.json` 记录 PX4 二进制哈希及依赖。','',
        '飞行来源以每例冻结 ZIP 为准：最新首例为包08，其余为包09；两版飞行控制源相同，09 修正起飞航向的离线审计。后续维护增加目标日志、默认 MAVROS 输入和交付核验，不把维护源码冒作已飞版本。','',
        'PX4 1.14.4，源提交 `07a18b2d120e69e2434e81e631e02b5beda0144b`，MAVROS 1.20.1，ROS Noetic，MuJoCo 3.10.0。Position 夹具和 PX4 EKF 继续使用模拟 GPS；Actor 没有水平导航输入。不是整机 GNSS 拒止、质量参数全域或正式独立留出验收。','',
        '固件日志存在磁力计 STALE 和加速度计零偏告警。当前证据只能确认消息链路与观察到的闭环失败，尚未隔离传感器／估计器时序、执行层和策略分布差异各自的影响，不能把失败全部归因于训练，也不能宣称更换接口后已经消除了质量敏感性。','',
        '全工程回归 248 项：247 通过、1 项平台跳过；另对后续日志／审计维护重跑 14 项接口测试通过。交付用 `python.cmd -B -m px4_offboard.dual_verify` 和根目录 `verify_project.py --strict-sources` 核对原始数据、回放、冻结模型与旧入口。完整 P3 的 PX4 内环迁移仍未完成。','',
        '[运行和一键入口](README.md)']
    (base/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('Report saved:',base/'report.md')


if __name__=='__main__':main()
