"""Read-only delivery checks for dual-interface source, raw flight and replay evidence."""
from pathlib import Path
import json
from zipfile import ZipFile
import numpy as np
from PIL import Image
from .dual_audit import read,digest


def verify():
    project=Path(__file__).resolve().parents[1];base=project/'px4_offboard/acceleration_dual'
    summary=read(base/'summary.json');current=read(project/'P2/models.json')['current']
    assert summary['controller_sha256']==current['sha256']==digest(project/current['checkpoint'])
    assert not summary['P3_enabled'] and not summary['formal_final_acceptance']
    for n,h in read(base/'assets/export.json')['artifact_sha256'].items():assert digest(base/'assets'/n)==h
    for n,h in summary['legacy_source_sha256'].items():assert digest(project/n)==h,n
    cases=summary['cases'];assert len(cases)==8
    replays=0
    for entry in cases:
        folder=base/entry['path'];a=read(folder/'audit.json');s=read(folder/'flight/summary.json')
        assert a==entry['audit']
        for n,h in a['artifact_sha256'].items():assert digest(folder/n)==h,(folder,n)
        with ZipFile(folder/'frozen_source.zip') as z:assert z.testzip() is None
        rows=np.load(folder/'flight/trace.npy');switch=s['switch_heartbeat_s']
        rows=rows[(rows[:,0]>=switch-1e-7)&(rows[:,0]<switch+120-1e-7)]
        assert len(rows)==a['actual_post_samples'] and a['evaluation_horizon_s']==120
        assert a['physical_post_duration_s']==len(rows)*.004
        assert len(rows)+a['penalized_remaining_samples']==30000
        error=rows[:,3:6]-[0,0,-a['target_baro_height_m']]
        h=(np.sum(error[:,2]**2)+16*(30000-len(rows)))/30000
        xy=(np.sum(error[:,:2]**2)+36*(30000-len(rows)))/30000
        np.testing.assert_allclose(np.sqrt([h+xy,h,xy]),a['rmse_3d_h_xy_m'],rtol=1e-12,atol=1e-12)
        assert a['safe_completed']==(s['error'] is None and len(rows)==30000)
        wire=read(folder/'wire_commands.json');assert wire['error'] is None
        assert len(wire['commands'])==a['actual_wire_commands']>0
        for c in wire['commands']:
            raw=bytes.fromhex(c['mavlink_hex']);mid=int.from_bytes(raw[7:10],'little') if raw[0]==253 else raw[5]
            m=c['message'];assert mid==(84 if a['interface']=='acceleration' else 82)
            assert m['type_mask']==(2363 if mid==84 else 128)
        if a['policy_source']=='mavros':
            runtime=read(folder/'policy_runtime.json')
            assert runtime['policy_steps']>0 and runtime['calibration_samples']==2000
            assert runtime['controller_sha256']==current['sha256']
        if entry['batch']=='full_02_mavros':
            media=read(folder/'replay/manifest.json')
            for n,h in media['source_sha256'].items():assert digest(folder/n)==h
            assert digest(folder/'replay/flight.gif')==media['GIF_sha256']
            assert media['physics_steps']==0 and media['equal_xyz_scale'] and media['start_s']==0
            np.testing.assert_allclose(media['end_s'],a['physical_post_duration_s'],atol=1e-9)
            with Image.open(folder/'replay/flight.gif') as im:
                assert im.n_frames==media['frames'];im.seek(im.n_frames-1);im.load()
            replays+=1
    assert replays==4
    return dict(cases=len(cases),current_cases=4,replays=replays,models_unchanged=True,
        safe_completed=sum(e['audit']['safe_completed'] for e in cases),
        rmse_passed=sum(e['audit']['rmse_passed'] for e in cases),formal_final_acceptance=False)


if __name__=='__main__':print(json.dumps(verify(),indent=2))
