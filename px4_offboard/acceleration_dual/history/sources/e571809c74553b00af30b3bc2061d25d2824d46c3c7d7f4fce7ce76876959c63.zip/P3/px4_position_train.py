"""Fit existing installation/bias/CG P3 from a completed real-PX4 Position capture."""
import argparse
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import numpy as np
from P2.hover_bptt.io import read,write,save,digest
from .installation_calibration import train_installed
from .actuator_calibration import fit_speed_gain
from .train_body_calibration import split_position


def excitation_window(samples):
    from .position_identification import POSITION_FIELDS,ODOMETRY_FIELDS
    active=np.asarray(samples['position_armed_airborne'],bool);indices=np.flatnonzero(active)
    if len(indices)<100 or not active[indices[0]:].all():raise ValueError('Need one continuous excited Position interval')
    start=float(samples['time_s'][indices[0]]);result={}
    for fields,clock,lower in ((POSITION_FIELDS,'time_s',start),(ODOMETRY_FIELDS,'position_time_s',start-.25)):
        mask=np.asarray(samples[clock])>=lower
        for key in fields:result[key]=np.asarray(samples[key])[mask].copy()
    return result


def train(capture,output,nominal,*,steps=1600):
    capture=Path(capture);output=Path(output);metadata=read(capture/'capture.json')
    if not metadata.get('real_PX4_Position') or not metadata.get('tether_force_disabled') or metadata.get('wind_mps')!=0:
        raise ValueError('Real Position and controlled zero wind/cable loads required')
    if metadata.get('Actor_used') or metadata.get('excitation_start_s') is None:
        raise ValueError('Need Position-only excitation before P3 fitting')
    summary=read(capture/'flight/summary.json')
    if summary['error'] is not None or summary['policy_ticks']:
        raise ValueError('Capture must complete safely without P2 takeover')
    samples=excitation_window(dict(np.load(capture/'position.npz')))
    output.mkdir(parents=True,exist_ok=False)
    repo=Path(__file__).resolve().parents[1]
    sources=['P3/px4_position_train.py','P3/installation_calibration.py','P3/body_calibration.py',
        'P3/position_identification.py','P3/train_body_calibration.py','P3/actuator_calibration.py']
    with ZipFile(output/'frozen_source.zip','x',ZIP_DEFLATED) as z:
        for n in sources:z.write(repo/n,n)
    input_sha=digest(capture/'position.npz')
    try:
        # No truth_only_physical values are passed to either fitter.
        model,optimizer,report=train_installed(samples,nominal,steps=steps,controlled_external_loads=True)
        training,held,_=split_position(samples)
        gain=fit_speed_gain(training,nominal)
        gain['holdout']=fit_speed_gain(held,nominal,speed_gain=gain['speed_gain'])
        report.update(input_sha256=input_sha,capture_metadata_sha256=digest(capture/'capture.json'),
            real_PX4_Position=True,independent_reference=metadata['independent_body_pose_reference'],
            P2_updates=0,source_sha256={n:digest(repo/n) for n in sources},
            px4_param_overrides=metadata['px4_param_overrides'])
        write(output/'actuator_gain.json',gain)
        record=dict(schema_version=2,model_kind='P3_installed_IMU_motor_axis_full_inertia',model=model.state_dict(),
            optimizer=optimizer.state_dict(),nominal=nominal,report=report)
        save(output/'calibration.pt',record)
        report['checkpoint_sha256']=digest(output/'calibration.pt');write(output/'training.json',report)
        print(dict(quality_passed=report['development_quality_gate_passed'],holdout=report['holdout'],
            axis_mass=report['axis_mass'],accel_bias=report['accel_bias_body_mps2'],com=report['com_geometry_m']),flush=True)
        if not report['development_quality_gate_passed']:raise RuntimeError('P3 holdout failed; do not enable compensation')
        return model,report
    except Exception as error:
        write(output/'failure.json',dict(error=f'{type(error).__name__}: {error}',input_sha256=input_sha,
            compensation_approved=False,truth_used_by_fitter=False))
        raise


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('capture',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--steps',type=int,default=1600)
    p.add_argument('--assets',type=Path,default=Path('px4_offboard/acceleration_dual/assets'))
    a=p.parse_args();train(a.capture,a.output,read(a.assets/'config.json')['nominal'],steps=a.steps)
