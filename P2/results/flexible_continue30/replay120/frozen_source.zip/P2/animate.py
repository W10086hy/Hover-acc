"""Offline animation of one archived complete evaluation;does not run a flight."""
from pathlib import Path
import argparse,math
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation,PillowWriter
from .hover_bptt.dynamics.torch_model import rotations
from .hover_bptt.io import read,write,digest
ROOT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--evaluation',default=str(ROOT/'results/baseline19/evaluation/seed20601201'))
    p.add_argument('--case',type=int,default=21);p.add_argument('--output',default=str(ROOT/'results/baseline19/current.gif'))
    p.add_argument('--start',type=float,default=0.);p.add_argument('--end',type=float,default=None);p.add_argument('--speed',type=float,default=12.)
    a=p.parse_args();torch.set_num_threads(2);directory=Path(a.evaluation);result=read(directory/'result.json');case=result['cases'][a.case]
    horizon=float(result.get('duration_s',120.));a.end=horizon if a.end is None else a.end
    if not 0<=a.start<a.end<=horizon or not .1<=a.speed<=30:raise ValueError('Valid archived range and playback speed required')
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():raise FileExistsError('Preserve previous animation')
    with np.load(directory/'trajectory.npz')as data:t=data['times'].copy();state=data['state'][:,a.case].copy()
    r=rotations(torch.from_numpy(state[:,6:10])).numpy();position=state[:,:3]*np.array([1,1,-1]);error=position-np.array([0,0,5])
    angles=np.rad2deg(np.stack((np.arctan2(r[:,2,1],r[:,2,2]),np.arcsin(-np.clip(r[:,2,0],-1,1)),np.arctan2(r[:,1,0],r[:,0,0])),axis=-1))
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans'];plt.rcParams['axes.unicode_minus']=False
    fig=plt.figure(figsize=(12,7),dpi=90);ax=fig.add_subplot(221,projection='3d');xy=fig.add_subplot(222);err=fig.add_subplot(223);att=fig.add_subplot(224)
    fig.subplots_adjust(top=.83,hspace=.45,wspace=.25)
    span=max(1.8,float(np.abs(position[:,:2]).max())+.6);ax.set(xlim=(-span,span),ylim=(-span,span),zlim=(0,6),xlabel='x / m',ylabel='y / m',zlabel='高度 / m')
    ax.view_init(elev=22,azim=-60);ax.scatter([0],[0],[5],c='black',marker='+');ax.plot(position[:,0],position[:,1],position[:,2],alpha=.25,color='tab:blue')
    drone,=ax.plot([],[],[],color='tab:blue',lw=3);cross,=ax.plot([],[],[],color='tab:blue',lw=3);nose,=ax.plot([],[],[],color='red',lw=3);rope,=ax.plot([],[],[],color='gray',lw=1)
    xy.plot(position[:,0],position[:,1],alpha=.6);xy.scatter([0],[0],c='black',marker='+');point,=xy.plot([],[],'ro');xy.set(xlim=(-span,span),ylim=(-span,span),xlabel='x / m',ylabel='y / m',title=f'全{horizon:g}秒水平轨迹');xy.set_aspect('equal');xy.grid(alpha=.3)
    for k,label in enumerate(['x','y','高度误差']):err.plot(t,error[:,k],label=label)
    err.set(xlabel='时间 / s',ylabel='误差 / m');err.legend(ncol=3,fontsize=8);err.grid(alpha=.3)
    for k,label in enumerate(['roll','pitch','yaw']):att.plot(t,angles[:,k],label=label)
    att.set(xlabel='时间 / s',ylabel='姿态 / deg');att.legend(ncol=3,fontsize=8);att.grid(alpha=.3)
    cursors=[pane.axvline(a.start,color='black',lw=1)for pane in [err,att]]
    samples=np.arange(a.start,a.end+1e-8,a.speed/10);indices=np.unique(np.clip(np.round(samples/.1).astype(int),0,len(t)-1))
    if indices[-1]!=round(a.end/.1):indices=np.append(indices,round(a.end/.1))
    arm=.05 if case['attachment']==2 else .1
    def line(artist,points):artist.set_data_3d(points[:,0],points[:,1],points[:,2])
    def frame(i):
        center=state[i,:3];rotation=r[i];convert=np.array([1,1,-1])
        # Display arms are enlarged;pose and tether attachment remain physical.
        line(drone,(center+np.array([[-.4,0,0],[.4,0,0]])@rotation.T)*convert)
        line(cross,(center+np.array([[0,-.4,0],[0,.4,0]])@rotation.T)*convert)
        line(nose,(center+np.array([[0,0,0],[.6,0,0]])@rotation.T)*convert)
        connection=(center+rotation@np.array([0,0,arm]))*convert
        if 'rope' in result:
            count=int(result['rope']['segments'])-1
            nodes=state[i,19:19+3*count].reshape(count,3)*convert
            line(rope,np.concatenate((np.zeros((1,3)),nodes,connection[None]),axis=0))
        else:line(rope,np.stack((np.zeros(3),connection)))
        point.set_data([position[i,0]],[position[i,1]])
        for cursor in cursors:cursor.set_xdata([t[i],t[i]])
        fig.suptitle(f"技术路线：BPTT｜{result.get('stage_label', '冻结策略验证')}｜累计{result['cumulative_physical_updates']}次动力学更新\n"
            f"{arm*100:.0f}cm连接点；基础风{case['wind_speed']:g}m/s，{math.degrees(case['direction_rad']):g}°，{case['wind_profile']}；机头0°；t={t[i]:.1f}s；{a.speed:g}×回放\n"
            f"全{horizon:g}秒 RMSE：3D {case['position_rmse_m']:.3f}m / 高度 {case['height_rmse_m']:.3f}m / 水平 {case['horizontal_rmse_m']:.3f}m"
            +(f"｜{case['safe_duration_s']:.2f}s失效，后续为冻结画面" if not case.get('completed',True) and t[i]>=case.get('safe_duration_s',horizon) else ''),fontsize=12)
        return drone,cross,nose,rope,point,*cursors
    animation=FuncAnimation(fig,frame,frames=indices,interval=100,blit=False);animation.save(out,writer=PillowWriter(fps=10));plt.close(fig)
    write(out.with_suffix('.json'),dict(checkpoint_sha256=result['checkpoint_sha256'],evaluation_seed_pair=result['seed_pair'],case_index=a.case,
        case=case,source_trajectory_sha256=digest(directory/'trajectory.npz'),gif_sha256=digest(out),route='BPTT',stage=result.get('stage_label',f"Frozen{result['cumulative_physical_updates']}physical_updates"),
        plotted_range_s=[a.start,a.end],playback_speed=a.speed,trajectory_sample_hz=10,metric_horizon_s=horizon,frames=len(indices),new_simulation=False))
    print(str(out),flush=True)
if __name__=='__main__':main()
