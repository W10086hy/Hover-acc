"""Reproducible, read-only numerical audit followed by metadata-only selection."""
from pathlib import Path
import copy
import hashlib
import json
import math
import sys
from zipfile import ZipFile,ZIP_DEFLATED

import numpy as np
import torch

REPO=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(REPO))
from P2.hover_bptt.io import read,write,save,digest,load_checkpoint
from P2.hover_bptt.generalization import cases_at
from P2.hover_bptt.vehicle_spec import identity
from P2.materialize_bptt_candidate import same,equivalent
from P2.prepare_optimizer_resume import prepare_resume
from P2.randomized_training import domains_for
from P2.select_bptt_candidate import _frozen_runtime
from P2.verify_stationarity import verify_evaluation

BASE=REPO/'P2/results/stationarity'
protocol=read(REPO/'P2/stationarity_position_refine_protocol.json')
candidate,candidate_sha=load_checkpoint(BASE/'candidate10_full/candidate.pt')
parent,parent_sha=load_checkpoint(BASE/'resume36/latest.pt')
selected36,selected36_sha=load_checkpoint(BASE/'selected36/latest.pt')
baseline_equivalence=equivalent(BASE/'candidate9_velocity32_thrust/candidate.pt',BASE/'selected36/latest.pt')
latest_equivalence=equivalent(BASE/'candidate10_full/candidate.pt',BASE/'step10_position/latest.pt')
expected_resume,_=prepare_resume(selected36,selected36_sha,parent['optimizer_state_conversion']['learning_rates'])
assert same(expected_resume,parent), 'Explicit optimizer conversion differs'
assert same(parent['actor'],selected36['actor']) and same(parent['configuration'],selected36['configuration'])
assert candidate['parent_checkpoint_sha256']==parent_sha
assert candidate['cumulative_physical_updates']==candidate['optimizer_steps']==37
assert selected36['cumulative_physical_updates']==parent['cumulative_physical_updates']==36
summary=read(BASE/'step10_position/training_summary.json')
manifest=read(BASE/'step10_position/run_manifest.json')
qualification=read(BASE/'qualification10_position/qualification.json')
assert manifest['parent_checkpoint_sha256']==qualification['parent_checkpoint_sha256']==parent_sha
assert identity(manifest['protocol'])==identity(protocol)==qualification['protocol_identity']
assert summary['completed'] and summary['accepted_updates']==1 and summary['trials'][-1]['fraction']==1
assert summary['retained_unvalidated_proposal']['optimizer_steps']==1
assert summary['retained_unvalidated_proposal']['checkpoint_sha256']==digest(BASE/'step10_position/proposal.pt')
assert math.isfinite(summary['gradient_norm']) and summary['gradient_norm']>0
assert summary['objective_s']==summary['credit_s']==30 and summary['recompute_s']==1
assert len(summary['gradient_diagnostics'])==2
for d in summary['gradient_diagnostics']:
    assert d['gradient_credit_steps']==3000 and d['recomputed_segments']==30
    assert d['maximum_recomputed_steps']==100 and d['warmup_control_steps']==9000
with ZipFile(BASE/'step10_position/frozen_source.zip') as archive:
    for name,sha in manifest['source_sha256'].items():
        assert hashlib.sha256(archive.read(name)).hexdigest()==sha
        assert digest(REPO/name)==sha, 'Runtime changed after training'
assert same(candidate['source_sha256'],manifest['source_sha256'])
for group in candidate['optimizer']['state'].values():
    assert all(bool(torch.isfinite(v).all()) for v in group.values() if isinstance(v,torch.Tensor))
assert torch.equal(candidate['actor']['fast_head.weight'][:,:8],parent['actor']['fast_head.weight'][:,:8])
assert torch.equal(candidate['actor']['fast_head.weight'][2],parent['actor']['fast_head.weight'][2])

domains=domains_for(protocol);expected_cases=cases_at(protocol['training_directions_deg'],protocol['training_winds'])
audits=[];result_hashes=[]
for label,index,device in [('nominal',0,'cpu'),('light',2,'cpu'),('heavy',1,'cpu'),('original_cuda',2,'cuda')]:
    folder=BASE/f'candidate10_{label}120'/domains[index]['name']
    old=BASE/f'velocity32thrust_{label}120'/domains[index]['name']
    result=read(folder/'result.json');run=read(folder.parent/'manifest.json')
    assert result['checkpoint_sha256']==run['checkpoint_sha256']==candidate_sha
    assert result['duration_s']==120 and result['count']==8 and result['safe_completed']==8
    assert result['device']==device and run['domains']==[index]
    assert identity(result['actual_vehicle_spec'])==identity(domains[index]['actual'].to_dict())
    assert identity(result['nominal_vehicle_spec'])==identity(domains[index]['nominal'].to_dict())
    assert identity(result['offline_limits'])==identity(candidate['configuration']['offline_limits'])
    assert result['seed_pair']==[protocol['training_seed']+10*index+j for j in (0,1)]
    assert identity(run['protocol'])==identity(protocol)
    _frozen_runtime(run,folder.parent/'frozen_source.zip',candidate)
    for case,wanted in zip(result['cases'],expected_cases):
        for key in ['attachment_b_m','wind_speed','direction_rad','wind_profile']:
            assert case[key]==wanted[key]
        assert case['heading_command_deg']==0 and case['stationarity_working_criteria_passed']
    with np.load(folder/'fullrate.npz') as raw:
        np.testing.assert_array_equal(raw['target_w_m'],[0.,0.,-5.])
    with np.load(folder/'trajectory.npz') as now,np.load(old/'trajectory.npz') as before:
        np.testing.assert_array_equal(now['state'][0],before['state'][0])
        np.testing.assert_array_equal(now['times'],before['times'])
    wind=torch.load(folder/'wind_trace.pt',map_location='cpu',weights_only=False)['wind_w_mps']
    oldwind=torch.load(old/'wind_trace.pt',map_location='cpu',weights_only=False)['wind_w_mps']
    assert torch.equal(wind,oldwind) and torch.equal(wind[401:],wind[401:402].expand_as(wind[401:]))
    audit=verify_evaluation(folder)
    assert audit['strong_stationary']==audit['strong_count']==4
    audits.append(dict(group=label,device=device,**audit))
    result_hashes.append(dict(group=label,result_sha256=digest(folder/'result.json'),
        raw_sha256=digest(folder/'fullrate.npz'),manifest_sha256=digest(folder.parent/'manifest.json')))
combined=read(BASE/'step10_fullscope_comparison.json')
assert combined['summary']['after']['count']==combined['summary']['after']['safe_completed']==32
assert combined['summary']['after']['strong_stationary']==combined['summary']['after']['strong_count']==16
assert combined['summary']['after']['rmse_3d_h_xy_m'][2]<combined['summary']['before']['rmse_3d_h_xy_m'][2]

output=BASE/'selected37'
output.mkdir(exist_ok=False)
selected=copy.deepcopy(candidate)
ancestry=selected.pop('bptt_selection',None)
selected.pop('goal_achieved',None)
selected.update(unvalidated_bptt_proposal=False,selected_for_use=True,
    validation_scope='32 representative development cases;not reserved formal final acceptance',
    parent_selection_ancestry=ancestry,bptt_selection=dict(candidate_checkpoint_sha256=candidate_sha,
        native_comparison_sha256=digest(BASE/'step10_native_comparison.json'),
        original_cuda_comparison_sha256=digest(BASE/'step10_cuda_comparison.json'),
        fullscope_comparison_sha256=digest(BASE/'step10_fullscope_comparison.json'),
        training_summary_sha256=digest(BASE/'step10_position/training_summary.json'),
        selection_source_sha256=digest(__file__),extra_optimizer_updates=0))
save(output/'latest.pt',selected)
proof=equivalent(BASE/'candidate10_full/candidate.pt',output/'latest.pt')
with ZipFile(output/'selection_source.zip','x',ZIP_DEFLATED) as archive:
    archive.write(__file__,'P2/results/stationarity/adopt37.py')
report=dict(selected_checkpoint_sha256=digest(output/'latest.pt'),candidate_checkpoint_sha256=candidate_sha,
    cumulative_physical_updates=37,optimizer_updates_in_selection=0,
    checkpoint_equivalence=proof,parent_policy_equivalence=baseline_equivalence,
    training_export_equivalence=latest_equivalence,explicit_resume_conversion_verified=True,
    native_audits=audits,result_hashes=result_hashes,fullscope_metrics=combined['summary'],
    fullscope_comparison_sha256=digest(BASE/'step10_fullscope_comparison.json'),
    source_archive_sha256=digest(output/'selection_source.zip'),formal_final_acceptance=False,
    media_and_final_delivery_audit_pending=True)
write(output/'selection_audit.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ['native_audits','checkpoint_equivalence',
    'parent_policy_equivalence','training_export_equivalence','result_hashes']},ensure_ascii=False),flush=True)
