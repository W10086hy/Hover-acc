"""Verify delivered attitude replays against frozen source data and policy."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
import json
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
BASE=OUT.parent
selected=BASE/'selected37/latest.pt'
expected='148e3a1ccb7f5a9b0f18668f089f4d5e9ffb161dd067fdbac3fe6669b5373ceb'
assert sha(selected)==expected
statistics=read(OUT/'attitude_statistics.json')
assert statistics['strong_count']==statistics['strong_tail_mean_into_wind_positive_count']==16
strong=[r for r in statistics['rows'] if r['wind_mps']==5]
assert all(r['into_wind_fraction']==1 for r in strong)
verified=[]
for name in ('strong','weak'):
    stem=OUT/(name+'120')
    meta=read(stem.with_suffix('.json'))
    assert meta['attitude_curves'] and meta['animation_end_s']==120 and meta['animation_start_s']==0
    assert meta['adopted_checkpoint_sha256']==expected
    assert meta['selection_audit_sha256']==sha(BASE/'selected37/selection_audit.json')
    assert meta['renderer_source_sha256']==sha(ROOT/'P2/visualize_full_flight.py')
    assert meta['equal_xyz_scale'] and meta['xyz_tick_step_m']==1
    assert meta['gif_sha256']==sha(stem.with_suffix('.gif'))
    assert meta['png_sha256']==sha(stem.with_suffix('.png'))
    with Image.open(stem.with_suffix('.gif')) as img:
        assert img.n_frames==201
        durations=[]
        for i in range(img.n_frames):
            img.seek(i);durations.append(img.info.get('duration',0))
        assert all(d==100 for d in durations)
    data=np.genfromtxt(OUT/(name+'_attitude.csv'),delimiter=',',names=True)
    assert data['time_s'][0]==0 and data['time_s'][-1]==120
    tail=data['time_s']>=90
    for field,column in [('roll_mean_deg','roll_deg'),('pitch_mean_deg','pitch_deg'),
                         ('yaw_mean_deg','yaw_deg'),('tilt_mean_deg','total_tilt_deg'),
                         ('into_wind_mean_deg','into_wind_tilt_deg')]:
        np.testing.assert_allclose(meta['tail30_attitude'][field],np.nanmean(data[column][tail]),atol=1e-5)
    source=BASE/'candidate10_light120/random_2'
    assert meta['source_trajectory_sha256']==sha(source/'trajectory.npz')
    assert meta['source_result_sha256']==sha(source/'result.json')
    assert meta['source_wind_sha256']==sha(source/'wind_trace.pt')
    verified.append(dict(name=name,frames=201,horizon_s=120,playback_speed=6,
        gif_sha256=meta['gif_sha256'],png_visually_inspected=True,attitude=meta['tail30_attitude']))
previous=read(BASE/'goal_completion_audit.json')
for path,expected_sha in previous['protected_weights'].items():assert sha(ROOT/path)==expected_sha
for old in previous['requirements'][-1]['media'].values():assert sha(ROOT/old['gif'])==old['gif_sha256']
with ZipFile(OUT/'frozen_plot_sources.zip','x',ZIP_DEFLATED) as archive:
    for source in (ROOT/'P2/visualize_full_flight.py',OUT/'summarize.py',Path(__file__)):
        archive.write(source,source.relative_to(ROOT).as_posix())
proof=dict(passed=True,policy_sha256=sha(selected),policy_and_adam_unchanged=True,
    previous_results_and_media_unchanged=True,no_training=True,no_new_simulation=True,
    frames_and_metrics_verified=verified,strong_count=16,all_strong_tail_samples_into_wind=True,
    source_archive_sha256=sha(OUT/'frozen_plot_sources.zip'),
    statistics_sha256=sha(OUT/'attitude_statistics.json'),
    roll_sign_check='Synthetic10deg rotation andwind reversal signs independently checked',
    curve_sample_hz=10,existing_flight_metric_sample_hz=100,
    formal_final_acceptance=False)
(OUT/'verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
reference=dict(report='P2/results/stationarity/replay_attitude37/README.md',
    verification='P2/results/stationarity/replay_attitude37/verification.json',
    checkpoint_sha256=sha(selected),no_training=True,no_new_simulation=True,
    strong='P2/results/stationarity/replay_attitude37/strong120.gif',
    weak='P2/results/stationarity/replay_attitude37/weak120.gif')
for path,key in [(ROOT/'project_state.json','stationarity_goal'),(ROOT/'P2/status.json','stationarity')]:
    state=read(path);state[key]['attitude_replays']=reference
    path.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False))
