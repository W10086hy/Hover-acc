"""Offline attitude-direction checks from archived trajectories, not a controller."""
from pathlib import Path
import json
import hashlib
import sys
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT))
from P2.hover_bptt.dynamics.torch_model import rotations

BASE=ROOT/'P2/results/stationarity'
OUT=Path(__file__).resolve().parent
rows=[]
for label,domain in [('nominal','nominal'),('light','random_2'),('heavy','random_1'),('original_cuda','random_2')]:
    directory=BASE/f'candidate10_{label}120'/domain
    result=json.loads((directory/'result.json').read_text(encoding='utf-8'))
    with np.load(directory/'trajectory.npz') as archive:
        t=archive['times'].copy();q=archive['state'][:,:,6:10].copy()
    R=rotations(torch.from_numpy(q.reshape(-1,4))).numpy().reshape(*q.shape[:2],3,3)
    recorded=torch.load(directory/'wind_trace.pt',map_location='cpu',weights_only=False)
    wind=recorded['wind_w_mps'][np.rint(t/recorded['dt_s']).astype(int)].numpy()
    unit=wind[:,:,:2]/np.maximum(np.linalg.norm(wind[:,:,:2],axis=2,keepdims=True),1e-9)
    roll=np.degrees(np.arctan2(R[:,:,2,1],R[:,:,2,2]))
    pitch=np.degrees(np.arcsin(np.clip(-R[:,:,2,0],-1,1)))
    yaw=np.degrees(np.arctan2(R[:,:,1,0],R[:,:,0,0]))
    tilt=np.degrees(np.arccos(np.clip(R[:,:,2,2],-1,1)))
    signed=np.degrees(np.arctan2(np.sum(R[:,:,:2,2]*unit,axis=2),R[:,:,2,2]))
    signed[np.linalg.norm(wind[:,:,:2],axis=2)<.1]=np.nan
    tail=t>=90
    for i,case in enumerate(result['cases']):
        row=dict(group=label,case_index=i,wind_mps=case['wind_speed'],
            wind_toward_deg=float(np.degrees(case['direction_rad'])),
            attachment_cm=case['attachment_b_m'][2]*100,
            roll_mean_deg=float(roll[tail,i].mean()),pitch_mean_deg=float(pitch[tail,i].mean()),
            yaw_mean_deg=float(yaw[tail,i].mean()),tilt_mean_deg=float(tilt[tail,i].mean()),
            into_wind_mean_deg=float(np.nanmean(signed[tail,i])),
            into_wind_fraction=float(np.mean(signed[tail,i]>0)),
            source_trajectory_sha256=hashlib.sha256((directory/'trajectory.npz').read_bytes()).hexdigest())
        rows.append(row)
        if label=='light' and i in (6,7):
            name='strong' if i==7 else 'weak'
            np.savetxt(OUT/f'{name}_attitude.csv',np.column_stack((t,roll[:,i],pitch[:,i],yaw[:,i],
                tilt[:,i],signed[:,i],wind[:,i,0],wind[:,i,1])),delimiter=',',
                header='time_s,roll_deg,pitch_deg,yaw_deg,total_tilt_deg,into_wind_tilt_deg,wind_x_mps,wind_y_mps',comments='')
strong=[row for row in rows if row['wind_mps']==5]
report=dict(definition='Positive into-wind angle means horizontal thrust projection opposes recorded air-flow direction',
    sample_hz=float(1/np.median(np.diff(t))),evaluation='archived simulation truth,offline only',
    horizon_s=120,tail_window_s=30,rows=rows,
    strong_tail_mean_into_wind_positive_count=sum(row['into_wind_mean_deg']>0 for row in strong),
    strong_count=len(strong),all_cases_claim_learned_aerodynamic_cancellation=False,
    caveat='Tether load also sets equilibrium attitude;no new no-wind matched ablation performed')
(OUT/'attitude_statistics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in report.items() if key!='rows'},ensure_ascii=False))
print(json.dumps([row for row in rows if row['group']=='light' and row['case_index'] in (6,7)],ensure_ascii=False))
