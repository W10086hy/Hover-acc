"""Bind all variable-wind media to immutable Actor37 and audited raw trajectories."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
import json
from PIL import Image

ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
expected='148e3a1ccb7f5a9b0f18668f089f4d5e9ffb161dd067fdbac3fe6669b5373ceb'
checkpoint=ROOT/'P2/results/stationarity/selected37/latest.pt'
assert sha(checkpoint)==expected
summary=read(BASE/'summary.json')
assert summary['summary']['count']==summary['summary']['safe_completed']==32
assert all(a['numerical_integrity_passed'] and a['fullrate_scoring_recomputed']
           and a['tail_motion_recomputed'] for a in summary['independent_fullrate_audits'])
assert summary['initial_states_exactly_paired_to_steady'] and summary['wind_formula_recomputed_bitwise']
assert summary['source_sha256']==sha(BASE/'summarize.py')
media=[]
for name,group,index in [('varying_weak120','light_varying',6),('varying_strong120','light_varying',7),
                         ('combined_weak120','light_combined',6),('combined_strong120','light_combined',7)]:
    stem=BASE/'replays'/name;meta=read(stem.with_suffix('.json'))
    raw=BASE/group/'random_2'
    assert meta['checkpoint_sha256']==expected and meta['cumulative_physical_updates']==37
    assert meta['case_index']==index and meta['attitude_curves']
    assert meta['animation_start_s']==0 and meta['animation_end_s']==meta['metric_horizon_s']==120
    assert meta['playback_speed']==6 and meta['frames']==201
    assert meta['equal_xyz_scale'] and meta['altitude_axis_min_m']==0 and meta['horizontal_distance_axis_min_m']==0
    assert meta['source_result_sha256']==sha(raw/'result.json')
    assert meta['source_trajectory_sha256']==sha(raw/'trajectory.npz')
    assert meta['source_wind_sha256']==sha(raw/'wind_trace.pt')
    assert meta['renderer_source_sha256']==sha(ROOT/'P2/visualize_full_flight.py')
    assert meta['gif_sha256']==sha(stem.with_suffix('.gif'))
    assert meta['png_sha256']==sha(stem.with_suffix('.png'))
    assert meta['case']['completed'] and meta['case']['safe_duration_s']==120
    with Image.open(stem.with_suffix('.gif')) as gif:
        assert gif.n_frames==201
        for frame in range(gif.n_frames):
            gif.seek(frame);assert gif.info['duration']==100
    media.append(dict(name=name,case_index=index,gif_sha256=meta['gif_sha256'],
        metadata_sha256=sha(stem.with_suffix('.json')),frames=201,full_horizon_s=120,
        png_visually_inspected=True,views=meta['views']))
protected=read(ROOT/'P2/results/stationarity/goal_completion_audit.json')['protected_weights']
assert all(sha(ROOT/path)==expected_sha for path,expected_sha in protected.items())
assert read(BASE/'run_state.json')['tests']['run']==read(BASE/'run_state.json')['tests']['passed']==10
with ZipFile(BASE/'frozen_report_sources.zip','x',ZIP_DEFLATED) as archive:
    for source in (Path(__file__),BASE/'summarize.py',ROOT/'P2/visualize_full_flight.py'):
        archive.write(source,source.relative_to(ROOT).as_posix())
verification=dict(passed=True,checkpoint_sha256=expected,actor_and_adam_unchanged=True,
    protected_old_weights_unchanged=True,complete_native_count=32,safe_completed=32,
    fullrate_numeric_audits=4,wind_field_bitwise_recomputed=True,
    initial_states_paired_to_prior_steady=True,media=media,
    summary_sha256=sha(BASE/'summary.json'),report_sha256=sha(BASE/'README.md'),
    frozen_report_sources_sha256=sha(BASE/'frozen_report_sources.zip'),
    tests=read(BASE/'run_state.json')['tests'],all_sessions_terminal=True,
    no_training=True,formal_final_acceptance=False,
    stationarity_thresholds_are_reference_for_variable_wind=True)
write(BASE/'verification.json',verification)
reference=dict(stage='complete',report='P2/results/time_varying37/README.md',
    verification='P2/results/time_varying37/verification.json',
    checkpoint_sha256=expected,duration_s=120,count=32,safe_completed=32,
    summary=summary['summary'],profiles=summary['profiles'],
    seed_pairs=[[20681101,20681102],[20681121,20681122]],
    training_running=False,validation_running=False,media_export_running=False,
    new_training=False,evaluation_sessions={},media_sessions={},formal_final_acceptance=False)
state=read(ROOT/'project_state.json')
state.update(validation_running=False,media_export_running=False)
state['time_varying37']=reference;write(ROOT/'project_state.json',state)
state=read(ROOT/'P2/status.json');state['time_varying37']=reference;write(ROOT/'P2/status.json',state)
state=read(BASE/'run_state.json')
state.update(stage='complete',evaluation_sessions={},media_sessions={},
    all_jobs_terminal=True,verification='P2/results/time_varying37/verification.json')
write(BASE/'run_state.json',state)
print(json.dumps(dict(passed=True,count=32,safe=32,media_count=len(media),
    checkpoint_sha256=expected,all_jobs_terminal=True),ensure_ascii=False))
