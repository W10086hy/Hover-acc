"""Audit frozen native variable-wind runs and report response separately from steady settling."""
from pathlib import Path
from zipfile import ZipFile
import csv
import hashlib
import json
import math
import sys
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from P2.verify_stationarity import verify_evaluation
from P2.hover_bptt.dynamics.torch_model import rotations
from P2.hover_bptt.wind import WindField

BASE=Path(__file__).resolve().parent
CHECKPOINT=ROOT/'P2/results/stationarity/selected37/latest.pt'
EXPECTED='148e3a1ccb7f5a9b0f18668f089f4d5e9ffb161dd067fdbac3fe6669b5373ceb'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert sha(CHECKPOINT)==EXPECTED
rows=[];audits=[];groups=[]
plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans']
plt.rcParams['axes.unicode_minus']=False
for label,domain in [('nominal_varying','nominal'),('nominal_combined','nominal'),
                     ('light_varying','random_2'),('light_combined','random_2')]:
    directory=BASE/label/domain
    result=read(directory/'result.json');manifest=read(directory.parent/'manifest.json')
    assert result['checkpoint_sha256']==manifest['checkpoint_sha256']==EXPECTED
    assert result['duration_s']==120 and result['count']==8
    assert result['policy_weights_unchanged'] and result['policy_updates']==0
    with ZipFile(directory.parent/'frozen_source.zip') as archive:
        for name,expected in manifest['source_sha256'].items():
            assert hashlib.sha256(archive.read(name)).hexdigest()==expected
            assert sha(ROOT/name)==expected
    independent=verify_evaluation(directory)
    audits.append(dict(group=label,**independent))
    steady=ROOT/'P2/results/stationarity'/('candidate10_nominal120' if domain=='nominal' else 'candidate10_light120')/domain
    with np.load(directory/'trajectory.npz') as current,np.load(steady/'trajectory.npz') as prior:
        np.testing.assert_array_equal(current['state'][0],prior['state'][0])
        np.testing.assert_array_equal(current['times'],prior['times'])
    stored=torch.load(directory/'wind_trace.pt',map_location='cpu',weights_only=False)
    wind=stored['wind_w_mps'].numpy()
    rebuilt=WindField(manifest['cases'],result['seed_pair'][1]).trace.numpy()
    np.testing.assert_array_equal(wind,rebuilt)
    assert np.std(wind[401:,:,:2],axis=0).min()>0.001
    with np.load(directory/'fullrate.npz') as archive:
        body=archive['body_state_ned'];failure=archive['failure_code'];invalid=archive['invalid_policy_action']
    alive=~np.maximum.accumulate((failure!=0)|invalid,axis=0)
    rotation=rotations(torch.from_numpy(body[:,:,6:10].reshape(-1,4))).numpy().reshape(*body.shape[:2],3,3)
    speed=np.linalg.norm(wind,axis=-1)
    horizontal=np.linalg.norm(wind[1:,:,:2],axis=-1)
    unit=wind[1:,:,:2]/np.maximum(horizontal[:,:,None],1e-9)
    signed=np.degrees(np.arctan2(np.sum(rotation[:,:,:2,2]*unit,axis=2),rotation[:,:,2,2]))
    tilt=np.degrees(np.arccos(np.clip(rotation[:,:,2,2],-1,1)))
    roll=np.degrees(np.arctan2(rotation[:,:,2,1],rotation[:,:,2,2]))
    pitch=np.degrees(np.arcsin(np.clip(-rotation[:,:,2,0],-1,1)))
    times=np.arange(1,len(body)+1)*.01
    steady_result=read(steady/'result.json')
    for i,c in enumerate(result['cases']):
        assert c['wind_profile'] in ('time_varying','combined')
        np.testing.assert_allclose(c['actual_peak_wind_mps'],speed[:,i].max(),atol=2e-6)
        mask=(times>=4)&alive[:,i]&(horizontal[:,i]>=.1)
        tail=(times>90)&mask
        row=dict(group=label,case_index=i,attachment_cm=c['attachment_b_m'][2]*100,
            direction_deg=math.degrees(c['direction_rad']),base_wind_mps=c['wind_speed'],profile=c['wind_profile'],
            seed_pair=result['seed_pair'],peak_wind_mps=c['actual_peak_wind_mps'],
            completed=c['completed'],safe_duration_s=c['safe_duration_s'],failure_code=c['failure_code'],
            rmse_3d_m=c['position_rmse_m'],height_rmse_m=c['height_rmse_m'],horizontal_rmse_m=c['horizontal_rmse_m'],
            late_horizontal_std_m=c['late_horizontal_std_m'],late_horizontal_speed_rms_mps=c['late_horizontal_speed_rms_mps'],
            late_horizontal_drift_mps=c['late_horizontal_drift_mps'],
            steady_horizontal_rmse_m=steady_result['cases'][i]['horizontal_rmse_m'],
            peak_tilt_deg=result['maximum_tilt_deg_per_case'][i],
            tail_mean_tilt_deg=float(tilt[tail,i].mean()) if tail.any() else None,
            tail_mean_into_wind_deg=float(signed[tail,i].mean()) if tail.any() else None,
            into_wind_fraction_after4s=float((signed[mask,i]>0).mean()) if mask.any() else None,
            into_wind_fraction_tail30s=float((signed[tail,i]>0).mean()) if tail.any() else None)
        rows.append(row)
    strong=[c for c in result['cases'] if c['wind_speed']>1]
    groups.append(dict(group=label,count=8,safe_completed=result['safe_completed'],
        rmse_3d_h_xy_m=result['rmse_3d_h_xy_m'],peak_wind_mps=float(speed.max()),
        max_yaw_error_deg=result['maximum_true_yaw_error_deg'],
        peak_tilt_deg=max(result['maximum_tilt_deg_per_case']),seed_pair=result['seed_pair'],
        wall_s=read(directory.parent/'summary.json')['wall_s']))
    if domain=='random_2':
        fig,axes=plt.subplots(4,2,figsize=(15,12),sharex=True)
        for col,i in enumerate((6,7)):
            case=result['cases'][i]
            axes[0,col].plot(np.arange(len(wind))*.01,speed[:,i],color='darkcyan')
            axes[0,col].axhline(case['wind_speed'],ls=':',color='black',lw=1)
            axes[0,col].set_title(f"基础{case['wind_speed']:g}m/s；瞬时峰值{case['actual_peak_wind_mps']:.2f}m/s")
            angle=np.degrees(np.arctan2(wind[1:,i,1],wind[1:,i,0]));angle[horizontal[:,i]<.1]=np.nan
            axes[1,col].plot(times,angle,color='darkcyan')
            axes[2,col].plot(times,roll[:,i],label='实际滚转',lw=1)
            axes[2,col].plot(times,pitch[:,i],label='实际俯仰',lw=1)
            axes[2,col].plot(times,np.where(horizontal[:,i]>=.1,signed[:,i],np.nan),label='迎风倾斜分量',lw=1,color='green')
            axes[2,col].axhline(0,ls=':',lw=1,color='black');axes[2,col].legend(fontsize=8,ncol=3)
            axes[3,col].plot(times,np.linalg.norm(body[:,i,:2],axis=1),color='tab:blue')
            axes[3,col].set_xlabel('仿真时间 / s');axes[3,col].set_ylim(bottom=0)
            for ax in axes[:,col]:
                ax.set_xlim(0,120);ax.grid(alpha=.25)
                if not case['completed']:ax.axvspan(case['safe_duration_s'],120,color='gray',alpha=.15)
        for ax,label_y in zip(axes[:,0],['瞬时风速 / m/s','气流去向 / °','姿态角 / °','水平距原点 / m']):ax.set_ylabel(label_y)
        fig.suptitle('技术路线：BPTT｜Actor37固定参数｜MuJoCo完整120秒\n'
            + ('纯时变风' if 'varying' in label else '时变风＋周期阵风＋OU湍流')
            +'｜轻机体、10cm挂点、平均风向90°；绿色正值表示推力迎风',fontsize=14)
        fig.tight_layout(rect=(0,0,1,.94));fig.savefig(BASE/(label+'_response.png'),dpi=120);plt.close(fig)

def aggregate(items):
    return dict(count=len(items),safe_completed=sum(r['completed'] for r in items),
        rmse_3d_h_xy_m=[math.sqrt(sum(r[key]**2 for r in items)/len(items)) for key in
            ('rmse_3d_m','height_rmse_m','horizontal_rmse_m')],
        peak_wind_mps=max(r['peak_wind_mps'] for r in items))
full=aggregate(rows)
profile_groups={profile:aggregate([r for r in rows if r['profile']==profile]) for profile in ('time_varying','combined')}
wind_groups={str(v):aggregate([r for r in rows if r['base_wind_mps']==v]) for v in (1,5)}
summary=dict(completed=True,checkpoint_sha256=EXPECTED,cumulative_physical_updates=37,
    no_training=True,policy_and_adam_unchanged=sha(CHECKPOINT)==EXPECTED,
    duration_s=120,summary=full,groups=groups,profiles=profile_groups,wind_groups=wind_groups,
    independent_fullrate_audits=audits,rows=rows,initial_states_exactly_paired_to_steady=True,
    wind_formula_recomputed_bitwise=True,steady_settling_criteria_reference_only=True,
    formal_final_acceptance=False,source_sha256=sha(Path(__file__)))
write(BASE/'summary.json',summary)
with (BASE/'statistics.csv').open('w',encoding='utf-8-sig',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
text_rows='\n'.join('| '+g['group']+f" | {g['safe_completed']}/8 | "
    +'/'.join(f'{v:.3f}' for v in g['rmse_3d_h_xy_m'])+f" | {g['peak_wind_mps']:.3f} | {g['max_yaw_error_deg']:.3f} |" for g in groups)
report=f'''# Actor37 冻结策略：时变风与组合阵风

当前37次策略与Adam保持不变，仅开展完整120秒MuJoCo前向验证。覆盖标称/轻机体、5/10cm挂点、平均风向0/90°、基础风速1/5m/s、两种风型，共32条。安全完成 **{full['safe_completed']}/32**，完整时域三维/高度/水平RMSE为 **{'/'.join(f'{v:.6f}' for v in full['rmse_3d_h_xy_m'])}m**。固定航向参考0°。

| 工况组 | 安全 | 三维/高度/水平RMSE m | 全组瞬时峰值 m/s | 最大航向误差 ° |
| --- | --- | --- | --- | --- |
{text_rows}

## 沿用的风定义

纯时变风：基础风速乘以1+0.2sin(2πt/30)，平均风向加30°sin(2πt/45)。组合风再叠加每20秒一次、持续4秒、最高20%基础风速的平滑脉冲，以及时间常数1.5秒的OU湍流，标准差为基础风速的水平各10%、垂向4%。前2秒无风、2–4秒建立。基础5m/s不代表峰值5m/s；实测峰值逐工况列在CSV。

两种定义来自现有WindField；弱风应用同一公式是本次新增覆盖，历史弱风未单独验证此类阵风。没有改变为峰值裁剪风，也不是8m移动小车分支的归一化风。当前目标高度5m、EA49N、12段有质量柔绳，5/10cm挂点绳长4.90/4.85m。种子标称20681101/02、轻机体20681121/22，CPU随机初始化与此前Actor37恒风验证的完整86维初态逐值相同。

持续变风会产生受迫运动。末30秒摆动、速度、漂移仍按原始定义报告，但不把恒风的静态稳态阈值作为本次是否能抗时变风的唯一结论。安全、误差、姿态方向和风变化响应分别报告，不因误差降低自动启动训练。尚未使用保留最终种子进行正式验收。

## 倾斜抗风与完整回放

姿态曲线来自实际仿真四元数。迎风倾斜分量按推力水平向量投影到气流反方向定义，正值表示推力迎风；机头无需跟随风转向，绳张力也参与平衡。逐工况姿态方向比例、倾角及稳定偏置见[完整CSV](statistics.csv)。

- [纯时变风：风速/风向与姿态响应](light_varying_response.png)
- [组合阵风：风速/风向与姿态响应](light_combined_response.png)
- 四份完整120秒、6倍、含3D/XY和姿态曲线的代表回放位于`replays`：纯时变弱风/强风、组合弱风/强风，均选轻机体10cm挂点90°平均风向。
- [原始统计与独立100Hz重算审计](summary.json)。各工况目录保留完整状态、命令、风场、航向、张力与失败证据；失败余时仍按原水平6m/高度4m计罚。

检查点SHA256：`{EXPECTED}`。使用现有机载35维历史与14维标称参数，未向控制器新增风、位置或速度真值，P3关闭。绘图只离线使用真值。四组原生仿真通过独立进程并行完成。
'''
(BASE/'README.md').write_text(report,encoding='utf-8')
print(json.dumps(dict(completed=True,summary=full,groups=groups,profiles=profile_groups,wind_groups=wind_groups),ensure_ascii=False))
