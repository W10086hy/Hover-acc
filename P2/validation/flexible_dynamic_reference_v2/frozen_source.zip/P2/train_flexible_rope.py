"""One measured P2 CUDA BPTT continuation with a distributed dynamic cable."""
import argparse,copy,time,zipfile
from pathlib import Path
import torch
from .hover_bptt.actor import Actor
from .hover_bptt.environment import plant_config
from .hover_bptt.flexible_environment import FlexibleRopeEnvironment
from .hover_bptt.flexible_training import ROOT,REPO,FlexibleRopeStream,validate_protocol,source_manifest,paired_update,progress
from .hover_bptt.generalization import cases_at
from .hover_bptt.io import read,write,save,load_checkpoint,digest
from .hover_bptt.optimizer import initialize,parameter_names
from .hover_bptt.plant import install_training_plant


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True)
    parser.add_argument('--qualification',required=True);parser.add_argument('--timing-reported',action='store_true')
    a=parser.parse_args();torch.set_num_threads(2)
    p=read(ROOT/'flexible_rope_protocol.json');validate_protocol(p);qual=read(Path(a.qualification)/'qualification.json')
    if not a.timing_reported or not qual['passed'] or qual['seconds']<1:raise ValueError('Report qualified iteration time before training')
    for name,sha in qual['source_sha256'].items():
        if digest(name)!=sha:raise ValueError('Qualification source changed: '+name)
    out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    parent=ROOT/p['parent_checkpoint'];saved,parent_sha=load_checkpoint(parent)
    if qual['parent_checkpoint_sha256']!=parent_sha:raise ValueError('Qualification parent differs')
    cfg=copy.deepcopy(saved['configuration']);cfg['training']['report_credit_progress']=True
    cfg['training']['dynamic_rope_objective']='actual path+heading+convergence; no stale-node target counterfactual'
    source=source_manifest();p3=REPO/'P3/results/residual/best.pt';p3_sha=digest(p3)
    torch.manual_seed(p['training_seed']);actor=Actor(cfg['model']).cuda();actor.load_state_dict(saved['actor']);actor.train()
    optimizer=initialize(actor,saved);base=plant_config();cases=cases_at(p['training_directions_deg'])
    manifest=dict(protocol=p,configuration=cfg,plant_configuration=base,source_sha256=source,
        parent_checkpoint_sha256=parent_sha,p3_checkpoint_sha256=p3_sha,qualification=qual,
        environment=dict(torch_version=torch.__version__,cuda_version=torch.version.cuda,gpu=torch.cuda.get_device_name()),
        original_adam_restored=True,p3_enabled=False,final_acceptance=False)
    write(out/'run_manifest.json',manifest)
    with zipfile.ZipFile(out/'frozen_source.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
        for name in source:archive.write(REPO/name,arcname=name)
    started=time.perf_counter();state=read(REPO/'project_state.json')
    state.update(training_running=True,validation_running=False,active_development_goal='PyTorch flexible rope P2 BPTT',
        development_priority='P2 CUDA dynamic flexible rope BPTT',p2_flexible_stage='training')
    write(REPO/'project_state.json',state)
    write(ROOT/'flexible_status.json',dict(stage='training',training_running=True,output=str(out),accepted_updates=0))
    try:
        env=FlexibleRopeEnvironment(len(cases),p['training_seed'],wind_seed=p['training_seed']+1,device='cuda',stage=cfg,
            episode_s=120,specifications=cases,rope=p['rope'])
        save(out/'training_wind.pt',dict(wind_w_mps=env.wind_field.trace.cpu(),dt_s=env.dt,cases=cases,seed_pair=[p['training_seed'],p['training_seed']+1]))
        install_training_plant(env);stream=FlexibleRopeStream(env);stream.hidden=env.state.new_zeros(1,env.n,cfg['model']['gru_hidden']);progress(stream)
        result=paired_update(stream,actor,optimizer,p)
        if source_manifest()!=source or digest(parent)!=parent_sha or digest(p3)!=p3_sha:raise RuntimeError('Source or protected parent changed during training')
        updates=int(saved['cumulative_physical_updates'])+int(result['accepted'])
        exported=copy.deepcopy(saved)
        exported.update(model_kind='P2_PyTorch_dynamic_flexible_rope_BPTT',configuration=cfg,plant_configuration=base,
            actor={k:v.detach().cpu() for k,v in actor.state_dict().items()},optimizer=optimizer.state_dict(),
            optimizer_parameter_names=parameter_names(actor,optimizer),cumulative_physical_updates=updates,optimizer_steps=updates,
            parent_checkpoint_sha256=parent_sha,source_sha256=source,flexible_rope_protocol=p,p3_enabled=False,goal_achieved=False)
        save(out/'latest.pt',exported)
        summary=dict(completed=True,accepted_updates=int(result['accepted']),cumulative_physical_updates=updates,
            wall_s=time.perf_counter()-started,checkpoint_sha256=digest(out/'latest.pt'),source_and_parents_unchanged=True,
            cases=cases,seed_pair=[p['training_seed'],p['training_seed']+1],p3_enabled=False,final_acceptance=False,**result)
        write(out/'training_summary.json',summary)
        write(ROOT/'flexible_status.json',dict(stage='trained_pending_development_comparison',training_running=False,output=str(out),
            accepted_updates=int(result['accepted']),checkpoint=str(out/'latest.pt'),checkpoint_sha256=summary['checkpoint_sha256']))
        print(dict(stage='flexible_training_complete',accepted_updates=int(result['accepted']),wall_s=summary['wall_s']),flush=True)
    finally:
        state=read(REPO/'project_state.json');state['training_running']=False;write(REPO/'project_state.json',state)


if __name__=='__main__':main()
