"""Dynamic cable state stays in the plant; policy observes only onboard data."""
import copy
from functools import partial
import torch
from tensordict import TensorDict
from .environment import RateEnvironment,DifferentiableRateEnvironment
from .flexible_rope import FlexibleRopeModel,DEFAULT_ROPE
from .vehicle_spec import identity


class _FlexibleRopeMixin:
    def __init__(self,*args,rope=None,**kwargs):
        self.flexible_rope_options={**DEFAULT_ROPE,**(rope or {})}
        kwargs.update(model_factory=partial(FlexibleRopeModel,rope=self.flexible_rope_options),capture=False,auto_reset=False)
        super().__init__(*args,**kwargs)
        self.trajectory_identity=identity(dict(base=self.trajectory_identity,backend='Torch_dynamic_flexible_rope_v1',
                                              rope=self.flexible_rope_options,state_width=self.model.state_width))

    def _reset(self,mask):
        super()._reset(mask)
        initialized=self.model.initialize_state(self.state[:,:19])
        self.state=torch.where(mask[:,None],initialized,self.state)

    def _observe(self,active=None):
        observed=super()._observe(active)
        return TensorDict({'policy':observed['policy']},[self.n])

    def metrics(self,wind=None):
        m=super().metrics(wind)
        peak=torch.maximum(m['tension'],self.state[:,-1])
        m['failure_code']=m['failure_code']|((peak>self.cfg['offline_limits']['tension_n']).long()<<7)
        m['flexible_interval_peak_tension_n']=peak
        return m


class FlexibleRopeEnvironment(_FlexibleRopeMixin,DifferentiableRateEnvironment):
    pass


class FlexibleRopeEvaluationEnvironment(_FlexibleRopeMixin,RateEnvironment):
    pass
