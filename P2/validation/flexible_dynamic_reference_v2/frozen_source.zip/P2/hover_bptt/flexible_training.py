"""Actual-trajectory objectives and bounded paired updates for dynamic cable."""
import copy
import math
import time
from pathlib import Path
import torch
from .actor import actor_mean
from .stream import RateFlightStream,heading_error_cost,settings,convergence_cost
from .state import snapshot,restore_stream
from .training import trajectory
from .io import digest,read

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent


class FlexibleRopeStream(RateFlightStream):
    """Keep the measured flight losses; no counterfactual with stale rope nodes."""
    def __init__(self,env):
        super().__init__(env);self.heading=settings(env.cfg)

    def step(self,actor):
        env=self.env;included=self.alive.clone();previous=env.state;motor=env.controller.previous
        cost=super().step(actor);extra=torch.zeros_like(cost).expand(env.n)
        if self.heading:extra=extra+heading_error_cost(env.state,self.heading)
        c=env.cfg['training'].get('hover_convergence_BPTT',{})
        if c.get('active',False):extra=extra+convergence_cost(previous,env.state,motor,env.controller.previous,
            env.model.target,self.steps*env.dt,env.dt,c)
        return cost+torch.where(included&self.alive,extra,torch.zeros_like(extra)).mean()


def validate_protocol(p):
    if (p['objective_s'],p['credit_s'],p['recompute_s'])!=(120,10,1):raise ValueError('Keep120/10/1')
    reserved={v for pair in read(ROOT/'acceptance.json')['final_seed_pairs'] for v in pair.values()}
    reserved|={v for pair in read(ROOT/'p2_protocol.json')['reserved_generalization_final_seed_pairs'] for v in pair}
    train={p['training_seed'],p['training_seed']+1};dev={p['development_seed'],p['development_seed']+1}
    if train&dev or (train|dev)&reserved:raise ValueError('Keep train/development/final seeds separate')
    if set(p['training_directions_deg'])&set(p['development_directions_deg']):raise ValueError('Hold out development directions')
    if p['final_acceptance'] or p['maximum_paired_trials'] not in (1,2,3):raise ValueError('Bounded development continuation only')


def source_manifest():
    files=sorted((ROOT/'hover_bptt').rglob('*.py'))+sorted((ROOT/'hover_bptt/configs').glob('*.json'))
    files+=[ROOT/name for name in ('configuration.json','flexible_rope_protocol.json',
        'qualify_flexible_rope.py','train_flexible_rope.py','evaluate_flexible_rope.py','animate.py')]
    return {p.relative_to(REPO).as_posix():digest(p) for p in files}


def progress(stream):
    native=stream.step;last=[time.perf_counter()]
    def step(actor):
        value=native(actor)
        if time.perf_counter()-last[0]>=25:
            last[0]=time.perf_counter()
            print(dict(stage='flexible_BPTT_recompute' if torch.is_grad_enabled() else 'flexible_forward',
                simulation_s=round(stream.steps*stream.env.dt,2),safe=int(stream.alive.sum()),count=stream.env.n),flush=True)
        return value
    stream.step=step


def paired_update(stream,actor,optimizer,protocol):
    before=snapshot(stream.env,stream,actor,optimizer,updates=0,episode=0,window=0)
    actor.zero_grad(set_to_none=True)
    loss,diag,baseline,base_commands=trajectory(stream,actor,gradient=True,steps=12000,credit_steps=1000,recompute_steps=100)
    norm=float(torch.nn.utils.clip_grad_norm_(actor.parameters(),1.,error_if_nonfinite=True))
    optimizer.step();proposal={k:v.detach().clone() for k,v in actor.state_dict().items()};adam=copy.deepcopy(optimizer.state_dict())
    trials=[];accepted=False
    for i in range(protocol['maximum_paired_trials']):
        restore_stream(stream.env,stream,actor,optimizer,before);fraction=.5**i
        actor.load_state_dict({k:v+fraction*(proposal[k]-v) for k,v in before['actor'].items()})
        _,_,candidate,commands=trajectory(stream,actor,steps=12000)
        rms=lambda s:math.sqrt(sum(v*v for v in s['position_rmse_m'])/len(s['completed']))
        reasons=[]
        if any(b and not a for b,a in zip(baseline['completed'],candidate['completed'])):reasons.append('new_failure')
        if candidate['cost']>=baseline['cost']:reasons.append('full_cost_not_lower')
        if rms(candidate)>rms(baseline)*1.05+.01:reasons.append('aggregate_position_regression')
        if any(a>b*1.1+.01 for a,b,ok in zip(candidate['height_rmse_m'],baseline['height_rmse_m'],baseline['completed']) if ok):
            reasons.append('safe_height_regression')
        accepted=not reasons
        trials.append(dict(fraction=fraction,accepted=accepted,reasons=reasons,score=candidate,
                           different_trajectory_max_command_change=(commands-base_commands).abs().amax((0,1)).tolist()))
        print(dict(stage='flexible_full120_candidate',fraction=fraction,accepted=accepted,cost=candidate['cost'],
                   safe=sum(candidate['completed']),reasons=reasons),flush=True)
        if accepted:optimizer.load_state_dict(adam);break
    if not accepted:restore_stream(stream.env,stream,actor,optimizer,before)
    if not torch.equal(actor.fast_head.weight[:,:8].detach(),before['actor']['fast_head.weight'][:,:8]):raise RuntimeError('Frozen fast feedback changed')
    return dict(**diag,accepted=accepted,gradient_objective_loss=loss,gradient_norm=norm,
                baseline=baseline,accepted_score=trials[-1]['score'] if accepted else baseline,trials=trials,
                continuous_objective_s=120,gradient_credit_s=10,recompute_s=1,full_untruncated120s_gradient=False)
