"""Short diagnostic timings; no optimiser and no change to plant arithmetic.

CPU inclusive ranges include enqueue/synchronisation overhead, so they are not
GPU utilisation percentages. Nested ranges must not be added together.
"""
import argparse
import copy
import time
from collections import defaultdict
from pathlib import Path
import torch
from torch.profiler import profile,record_function,ProfilerActivity
from .hover_bptt.actor import Actor
from .hover_bptt.flexible_environment import FlexibleRopeEnvironment
from .hover_bptt.flexible_training import FlexibleRopeStream
from .hover_bptt.generalization import cases_at
from .hover_bptt.io import read,write,load_checkpoint,digest
from .hover_bptt.plant import install_training_plant
from .hover_bptt.gradient import checkpointed_window

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True)
    parser.add_argument('--steps',type=int,default=20)
    args=parser.parse_args()
    if not 3<=args.steps<=100:raise ValueError('Short profile only:3..100 control steps')
    out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
    torch.set_num_threads(2)
    p=read(ROOT/'flexible_rope_protocol.json');saved,sha=load_checkpoint(ROOT/p['parent_checkpoint'])
    cfg=copy.deepcopy(saved['configuration']);cfg['training']['report_credit_progress']=False
    cases=cases_at(p['training_directions_deg'])
    env=FlexibleRopeEnvironment(len(cases),20673101,wind_seed=20673102,device='cuda',stage=cfg,
        episode_s=1.,specifications=cases,rope=p['rope'])
    actor=Actor(cfg['model']).cuda();actor.load_state_dict(saved['actor']);actor.train()
    install_training_plant(env)
    stream=FlexibleRopeStream(env);stream.hidden=env.state.new_zeros(1,env.n,128)
    timings=defaultdict(lambda:dict(calls=0,inclusive_wall_s=0.))
    def wrap(obj,name,label):
        original=getattr(obj,name)
        def call(*a,**kw):
            started=time.perf_counter()
            with record_function(label):value=original(*a,**kw)
            timings[label]['calls']+=1
            timings[label]['inclusive_wall_s']+=time.perf_counter()-started
            return value
        setattr(obj,name,call)
    wrap(actor,'forward','actor')
    wrap(env.controller,'apply','controller_PI_allocation')
    wrap(env.model,'control','plant_control_forward')
    wrap(env,'_observe','onboard_observation')
    wrap(env.sensors,'sample','sensor_sample')
    wrap(env.history,'update','onboard_history')
    wrap(env,'metrics','offline_metrics')
    activities=[ProfilerActivity.CPU]
    cuda_supported=ProfilerActivity.CUDA in torch.profiler.supported_activities()
    if cuda_supported:activities.append(ProfilerActivity.CUDA)
    torch.cuda.synchronize();started=time.perf_counter()
    with profile(activities=activities,record_shapes=False,profile_memory=False) as prof:
        with record_function('complete_checkpointed_BPTT'):
            loss,diag=checkpointed_window(stream,actor,args.steps,segment_steps=args.steps)
            torch.cuda.synchronize()
    elapsed=time.perf_counter()-started
    rows=[]
    for event in prof.key_averages():
        rows.append(dict(name=event.key,count=event.count,self_cpu_ms=event.self_cpu_time_total/1000,
            inclusive_cpu_ms=event.cpu_time_total/1000,
            self_device_ms=getattr(event,'self_device_time_total',0.)/1000,
            inclusive_device_ms=getattr(event,'device_time_total',0.)/1000))
    rows.sort(key=lambda row:row['self_cpu_ms'],reverse=True)
    unchanged=digest(ROOT/p['parent_checkpoint'])==sha and all(torch.equal(v.detach().cpu(),saved['actor'][k]) for k,v in actor.state_dict().items())
    if not unchanged:raise RuntimeError('Profiling changed the checkpoint')
    result=dict(steps=args.steps,simulation_s=args.steps*.01,count=len(cases),device='cuda',
        gpu=torch.cuda.get_device_name(),torch_version=torch.__version__,cuda_version=torch.version.cuda,
        cuda_profiler_supported=cuda_supported,profile_wall_s=elapsed,loss=loss,diagnostics=diag,
        cpu_inclusive_ranges=dict(timings),events=rows,
        interpretation='Instrumented short run; timings include profiler overhead and nested ranges; not a training throughput benchmark',
        parent_unchanged=unchanged,optimizer_created=False,source_sha256=digest(__file__),
        frozen_30s_completion_audit_sha256=digest(ROOT/'validation/flexible_rope_30s/completion_audit.json'))
    write(out/'profile.json',result)
    print(dict(profile_wall_s=elapsed,cuda_profiler_supported=cuda_supported,ranges=dict(timings),top_self_cpu=rows[:12]),flush=True)


if __name__=='__main__':main()
