"""Show archived physical cable nodes and their deviation from the endpoint chord."""
import argparse,math
from pathlib import Path
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation,PillowWriter
from .hover_bptt.dynamics.torch_model import rotations
from .hover_bptt.io import read,write,digest


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--evaluation',required=True)
    p.add_argument('--case',type=int,default=3);p.add_argument('--output',required=True);p.add_argument('--speed',type=float,default=6.)
    a=p.parse_args();directory=Path(a.evaluation);out=Path(a.output)
    if out.exists():raise FileExistsError('Preserve previous visualization')
    result=read(directory/'result.json');case=result['cases'][a.case]
    if 'rope' not in result:raise ValueError('Archived distributed cable required')
    data=np.load(directory/'trajectory.npz');t=data['times'];state=data['state'][:,a.case]
    count=result['rope']['segments']-1
    R=rotations(torch.from_numpy(state[:,6:10])).numpy()
    arm=.05 if case['attachment']==2 else .1
    endpoint=state[:,:3]+R@np.array([0.,0.,arm])
    nodes=state[:,19:19+count*3].reshape(len(t),count,3)
    points=np.concatenate((np.zeros((len(t),1,3)),nodes,endpoint[:,None]),1)
    unit=endpoint/np.linalg.norm(endpoint,axis=-1,keepdims=True)
    coordinate=(points*unit[:,None]).sum(-1)
    deviation=points-coordinate[:,:,None]*unit[:,None]
    max_perpendicular=np.linalg.norm(deviation,axis=-1).max(-1)
    wind_basis=np.array([math.cos(case['direction_rad']),math.sin(case['direction_rad']),0.])
    axis=wind_basis-(unit*wind_basis).sum(-1,keepdims=True)*unit
    axis=axis/np.maximum(np.linalg.norm(axis,axis=-1,keepdims=True),1e-9)
    signed=(deviation*axis[:,None]).sum(-1)*100
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans'];plt.rcParams['axes.unicode_minus']=False
    fig=plt.figure(figsize=(13,7),dpi=100)
    ax=fig.add_subplot(131,projection='3d');bend=fig.add_subplot(132);trace=fig.add_subplot(133)
    fig.subplots_adjust(left=.06,right=.97,top=.77,bottom=.13,wspace=.45)
    limit=max(1.,float(np.abs(points[:,:,:2]).max())+.25)
    ax.set(xlim=(-limit,limit),ylim=(-limit,limit),zlim=(0,6),xlabel='x / m',ylabel='y / m',zlabel='高度 / m',title='真实节点；灰虚线为端点连线')
    ax.view_init(elev=18,azim=-40)
    rope,=ax.plot([],[],[],color='tab:orange',marker='o',markersize=3,lw=2)
    chord,=ax.plot([],[],[],color='gray',ls='--',lw=1)
    body,=ax.plot([],[],[],'b-',lw=3)
    span=max(5.,float(np.abs(signed).max())*1.15)
    bend.set(xlim=(-span,span),ylim=(0,6),xlabel='沿风向的垂直连线偏移 / cm',ylabel='沿端点连线的坐标 / m',title='局部挠度视图（横纵单位不同）')
    bend.axvline(0,color='gray',ls='--');bend.grid(alpha=.3)
    profile,=bend.plot([],[],color='tab:orange',marker='o',markersize=4)
    trace.plot(t,max_perpendicular*100,color='tab:orange')
    trace.set(xlabel='时间 / s',ylabel='最大垂直连线偏移 / cm',title='每帧真实三维挠度')
    trace.grid(alpha=.3);cursor=trace.axvline(0,color='black');label=trace.text(.03,.96,'',transform=trace.transAxes,va='top')
    indices=np.unique(np.clip(np.round(np.arange(0,result['duration_s']+1e-8,a.speed/10)/.1).astype(int),0,len(t)-1))
    if indices[-1]!=len(t)-1:indices=np.append(indices,len(t)-1)
    convert=np.array([1,1,-1])
    def line(artist,p):artist.set_data_3d(p[:,0],p[:,1],p[:,2])
    def frame(i):
        line(rope,points[i]*convert);line(chord,np.stack((np.zeros(3),endpoint[i]))*convert)
        line(body,(state[i,:3]+np.array([[-.3,0,0],[.3,0,0]])@R[i].T)*convert)
        profile.set_data(signed[i],coordinate[i]);cursor.set_xdata([t[i],t[i]])
        label.set_text(f'当前挠度 {max_perpendicular[i]*100:.1f}cm\n全程峰值 {max_perpendicular.max()*100:.1f}cm')
        fig.suptitle('技术路线：BPTT｜P2动态柔绳；30秒梯度验证；策略未更新\n'
            f'{arm*100:.0f}cm连接点；基础风{case["wind_speed"]:g}m/s，瞬时峰值{case["actual_peak_wind_mps"]:.3f}m/s；'
            f'{math.degrees(case["direction_rad"]):g}°，{case["wind_profile"]}；t={t[i]:.1f}s；{a.speed:g}×回放\n'
            f'全{result["duration_s"]:g}秒 RMSE 3D/高度/水平：{case["position_rmse_m"]:.3f}/{case["height_rmse_m"]:.3f}/{case["horizontal_rmse_m"]:.3f}m；安全{int(case["completed"])}/1',fontsize=12)
        return rope,chord,body,profile,cursor,label
    out.parent.mkdir(parents=True,exist_ok=True)
    anim=FuncAnimation(fig,frame,frames=indices,interval=100,blit=False);anim.save(out,writer=PillowWriter(fps=10))
    peak=int(max_perpendicular.argmax());frame(peak);fig.savefig(out.with_suffix('.png'));plt.close(fig)
    write(out.with_suffix('.json'),dict(case_index=a.case,case=case,source_trajectory_sha256=digest(directory/'trajectory.npz'),
        checkpoint_sha256=result['checkpoint_sha256'],seed_pair=result['seed_pair'],metric_horizon_s=result['duration_s'],
        playback_speed=a.speed,frames=len(indices),maximum_perpendicular_chord_distance_m=float(max_perpendicular.max()),
        peak_time_s=float(t[peak]),gif_sha256=digest(out),png_sha256=digest(out.with_suffix('.png')),
        visualization_only=True,new_simulation=False,coordinates='Physical3D nodes; right-panel lateral cm versus chord-coordinate m'))
    print(dict(output=str(out),peak_time_s=float(t[peak]),maximum_perpendicular_chord_distance_m=float(max_perpendicular.max())),flush=True)


if __name__=='__main__':main()
