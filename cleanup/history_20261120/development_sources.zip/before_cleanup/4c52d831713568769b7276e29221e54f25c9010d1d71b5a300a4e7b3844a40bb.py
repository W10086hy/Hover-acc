"""Export an experimental response map from frozen joint residual coefficients.

This is an observation adapter, not physical torque feedforward or a physical
parameter identification. No optimizer, truth, wind or tether data is used.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from px4_offboard.aligned_p3 import AlignedCalibration


def response_map(parameters):
    reference=parameters['reference_physics']
    dx,dy=reference['rotor_dx_m'],reference['rotor_dy_m']
    kf,km=reference['kf'],reference['km']
    nominal=np.array([[-dy*kf,-dy*kf,dy*kf,dy*kf],
        [dx*kf,-dx*kf,dx*kf,-dx*kf],[km,-km,-km,km]])/np.asarray(reference['inertia'])[:,None]
    weights=np.asarray(parameters['angular_weights'])
    # Quasistatic response: previous/current/measured interval squares coincide.
    residual=(weights[:,13:17]+weights[:,17:21]+weights[:,21:25])/360000.
    gain=np.eye(3)+residual@np.linalg.pinv(nominal)
    inverse=np.linalg.inv(gain)
    return inverse,gain


def export(parent,output):
    original=Path(parent).read_bytes();parameters=json.loads(original)
    AlignedCalibration(parameters)
    if parameters.get('feature_support_fallback')!='training_mean':
        raise ValueError('Response experiment requires retained self-disturbance mean')
    inverse,gain=response_map(parameters)
    parameters['angular_innovation_map']=inverse.tolist()
    parameters['scope']+='; experimental frozen-coefficient angular response normalization'
    parameters['response_export']={
        'parent_sha256':hashlib.sha256(original).hexdigest(),
        'definition':'inverse of I plus quasistatic residual RPM response projected on nominal angular actuation',
        'response_gain':gain.tolist(),'singular_values':np.linalg.svd(gain,compute_uv=False).tolist(),
        'P2_updates':0,'P3_optimizer_updates':0,
        'status':'DEVELOPMENT_CANDIDATE_NOT_ACCEPTED',
        'limitation':'Position regression coefficients can mix force and actuation effects; closed-loop validation required'}
    AlignedCalibration(parameters)
    with Path(output).open('x',encoding='utf-8') as stream:
        json.dump(parameters,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps(parameters['response_export'],indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parent',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();export(args.parent,args.output)
